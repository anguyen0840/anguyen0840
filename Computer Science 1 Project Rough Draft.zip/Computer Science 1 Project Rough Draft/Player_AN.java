import java.io.*;
import java.util.*;

public class Player_AN extends Person_AN{
    private  int playerID;
    String player;
    private int gameScore;;

    private int numberCorrectAnswer;

    public Player_AN () {
        super();
    }

    public Player_AN (int playerID, String player, int gameScore) {
        super();
        this.playerID = playerID;
        this.player = player;
        this.gameScore = gameScore;
    }

    public int getPlayerID() {
        return playerID;
    }

    public void setPlayerID(int playerID) {
        this.playerID = playerID;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public int getGameScore() {
        return gameScore;
    }

    public void setGameScore(int gameScore) {
        this.gameScore = this.gameScore + gameScore;
        if(gameScore > 0) {
            this.numberCorrectAnswer++;
        }
    }

    public void generateResults() {
        System.out.println("ID: " + getPlayerID());
        System.out.println("Player's Name: " + getFirstName() + " " + getLastName());
        System.out.println("Number of Correct Answers: " + numberCorrectAnswer);
        System.out.println("Number of Incorrect Answers: " + (4 - numberCorrectAnswer));
    }

    public void generateResultsIntoFile() throws IOException {
        FileOutputStream fileOutputStream;//create a variable from FileOutputStream
        PrintWriter outFS;//create a variable called outFS from PrintWriter

        String fileName = "AnimeGuessingGameScores_AN-" + System.currentTimeMillis() + " .txt";
        File file = new File(fileName);

        if(file.exists()) {
            file.createNewFile();
        } else {
            System.out.println("File Already Exists.");
        }

        fileOutputStream = new FileOutputStream(file, true);//variable called FileOutputStream to create an instance for text file, BankAccountStatement_AN.txt, to be created
        outFS = new PrintWriter(fileOutputStream);//create an instance for variable fileOutputStream to be used into PrintWriter() method

        outFS.println("ID: " + getPlayerID());
        outFS.println("Player's Name: " + getFirstName() + " " + getLastName());
        outFS.println("Number of Correct Answers: " + numberCorrectAnswer);
        outFS.println("Number of Incorrect Answers: " + (4 - numberCorrectAnswer));

        outFS.flush();//clears the PrintWriter variable
        fileOutputStream.close();//closes text file
    }

    @Override
    public String getInfo() {
        String personInfo;
        personInfo = "Full Name: " + getFirstName() + " " + getLastName() + "\n" +  "ID: " + getPlayerID() + "\n" + "Score: " + getGameScore();
        return personInfo;
    }
}

