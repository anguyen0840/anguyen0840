import javax.imageio.ImageIO;//import for javax.swing, java.awt, java.awt.event, java.io, java.util, and java.imageio
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GuessingGameGUI_AN extends WindowAdapter {//list all class member variables
    Player_AN playerObject;
   // Person_AN personObject;
    List<Player_AN> playerList = new ArrayList<>();
    int numberOfQuestionsAnswered = 0;
    boolean gameInProgress = false;

    JFrame guessingGameFrame = new JFrame("Anime Guessing Game");//JFrame, JPanel, and JLabel for opening window
    JPanel guessingGamePanel = new JPanel(new FlowLayout());
    JLabel guessingGameLabel = new JLabel("Welcome to the Anime Guessing Game.");

    JButton oKStartButton = new JButton("OK");//OK and Cancel for 1-10
    JButton cancelStartButton = new JButton("Cancel");

    JButton oKNumberOneButton = new JButton("OK");
    JButton cancelNumberOneButton = new JButton("Cancel");

    JButton oKNumberTwoButton = new JButton("OK");
    JButton cancelNumberTwoButton = new JButton("Cancel");

    JButton oKNumberThreeButton = new JButton("OK");
    JButton cancelNumberThreeButton = new JButton("Cancel");

    JButton oKNumberFourButton = new JButton("OK");
    JButton cancelNumberFourButton = new JButton("Cancel");

    JButton oKNumberFiveButton = new JButton("OK");
    JButton cancelNumberFiveButton = new JButton("Cancel");

    JButton oKNumberSixButton = new JButton("OK");
    JButton cancelNumberSixButton = new JButton("Cancel");

    JButton oKNumberSevenButton = new JButton("OK");
    JButton cancelNumberSevenButton = new JButton("Cancel");

    JButton oKNumberEightButton = new JButton("OK");
    JButton cancelNumberEightButton = new JButton("Cancel");

    JButton oKNumberNineButton = new JButton("OK");
    JButton cancelNumberNineButton = new JButton("Cancel");

    JButton oKNumberTenButton = new JButton("OK");
    JButton cancelNumberTenButton = new JButton("Cancel");

    JButton oKInformationButton = new JButton("OK");
    JButton cancelInformationButton = new JButton("Cancel");

    JButton oKResultsButton = new JButton("OK");

    JButton oKLeaderBoardButton = new JButton("OK");

    JButton oKHelpButton = new JButton("OK");

    JButton oKPrintScoreToAFileButton = new JButton("OK");
    JButton cancelPrintScoreToAFileButton = new JButton("Cancel");

    JButton startButton = new JButton("Start");//Start Button with Panels and Frame
    JPanel startButtonPanel = new JPanel(new FlowLayout());
    JPanel startTextBoxPanel = new JPanel(new FlowLayout());
    JFrame startFrame = new JFrame("Start the Anime Guessing Game");

    JButton numberOneButton = new JButton("1");//Number One Question Member Variables
    JFrame numberOneFrame = new JFrame("Anime Guessing Game Question 1");
    JPanel numberOneButtonPanel = new JPanel(new FlowLayout());
    JPanel numberOneTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberOneMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberOneLabel = new JLabel("What Year Was the First Anime Recorded?");
    ButtonGroup questionNumberOneButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberOneChoiceARadioButton = new JRadioButtonMenuItem("A. 1891");
    JRadioButtonMenuItem numberOneChoiceBRadioButton = new JRadioButtonMenuItem("B. 1900");
    JRadioButtonMenuItem numberOneChoiceCRadioButton = new JRadioButtonMenuItem("C. 1913");
    JRadioButtonMenuItem numberOneChoiceDRadioButton = new JRadioButtonMenuItem("D. 1917");

    JButton numberTwoButton = new JButton("2");//Number Two Question Member Variables
    JFrame numberTwoFrame = new JFrame("Anime Guessing Game Question 2");
    JPanel numberTwoButtonPanel = new JPanel(new FlowLayout());
    JPanel numberTwoTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberTwoMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberTwoLabel = new JLabel("How Many Types of Pokemon Are There?");
    ButtonGroup questionNumberTwoButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberTwoChoiceARadioButton = new JRadioButtonMenuItem("A. 15");
    JRadioButtonMenuItem numberTwoChoiceBRadioButton = new JRadioButtonMenuItem("B. 18");
    JRadioButtonMenuItem numberTwoChoiceCRadioButton = new JRadioButtonMenuItem("C. 20");
    JRadioButtonMenuItem numberTwoChoiceDRadioButton = new JRadioButtonMenuItem("D. 24");

    JButton numberThreeButton = new JButton("3");//Number Three Question Member Variables
    JFrame numberThreeFrame = new JFrame("Anime Guessing Game Question 3");
    JPanel numberThreeButtonPanel = new JPanel(new FlowLayout());
    JPanel numberThreeTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberThreeMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberThreeLabel = new JLabel("Who Has the Nickname of 'One Punch Man'?");
    ButtonGroup questionNumberThreeButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberThreeChoiceARadioButton = new JRadioButtonMenuItem("A. Son Goku");
    JRadioButtonMenuItem numberThreeChoiceBRadioButton = new JRadioButtonMenuItem("B. Monkey D. Luffy");
    JRadioButtonMenuItem numberThreeChoiceCRadioButton = new JRadioButtonMenuItem("C. Saitama");
    JRadioButtonMenuItem numberThreeChoiceDRadioButton = new JRadioButtonMenuItem("D. Uzumaki Naruto");

    JButton numberFourButton = new JButton("4");//Number Four Question Member Variables
    JFrame numberFourFrame = new JFrame("Anime Guessing Game Question 4");
    JPanel numberFourButtonPanel = new JPanel(new FlowLayout());
    JPanel numberFourTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberFourMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberFourLabel = new JLabel("How Many Dragon Balls Are There?");
    ButtonGroup questionNumberFourButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberFourChoiceARadioButton = new JRadioButtonMenuItem("A. 7");
    JRadioButtonMenuItem numberFourChoiceBRadioButton = new JRadioButtonMenuItem("B. 8");
    JRadioButtonMenuItem numberFourChoiceCRadioButton = new JRadioButtonMenuItem("C. 6");
    JRadioButtonMenuItem numberFourChoiceDRadioButton = new JRadioButtonMenuItem("D. 9");

    JButton numberFiveButton = new JButton("5");//Number Five Question Member Variables
    JFrame numberFiveFrame = new JFrame("Anime Guessing Game Question 5");
    JPanel numberFiveButtonPanel = new JPanel(new FlowLayout());
    JPanel numberFiveTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberFiveMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberFiveLabel = new JLabel("'Haikyuu!!' Is An Anime Centered Around A Boy Who Wants To Be Successful in Which Sport?");
    ButtonGroup questionNumberFiveButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberFiveChoiceARadioButton = new JRadioButtonMenuItem("A. Volleyball");
    JRadioButtonMenuItem numberFiveChoiceBRadioButton = new JRadioButtonMenuItem("B. Basketball");
    JRadioButtonMenuItem numberFiveChoiceCRadioButton = new JRadioButtonMenuItem("C. Baseball");
    JRadioButtonMenuItem numberFiveChoiceDRadioButton = new JRadioButtonMenuItem("D. Golf");

    JButton numberSixButton = new JButton("6");//Number Six Question Member Variables
    JFrame numberSixFrame = new JFrame("Anime Guessing Game Question 6");
    JPanel numberSixButtonPanel = new JPanel(new FlowLayout());
    JPanel numberSixTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberSixMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberSixLabel = new JLabel("In Noragami, Yato Is the God of What?");
    ButtonGroup questionNumberSixButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberSixChoiceARadioButton = new JRadioButtonMenuItem("A. Violence");
    JRadioButtonMenuItem numberSixChoiceBRadioButton = new JRadioButtonMenuItem("B. Misfortune");
    JRadioButtonMenuItem numberSixChoiceCRadioButton = new JRadioButtonMenuItem("C. Vengeance");
    JRadioButtonMenuItem numberSixChoiceDRadioButton = new JRadioButtonMenuItem("D. Calamity/War");

    JButton numberSevenButton = new JButton("7");//Number Seven Question Member Variables
    JFrame numberSevenFrame = new JFrame("Anime Guessing Game Question 7");
    JPanel numberSevenButtonPanel = new JPanel(new FlowLayout());
    JPanel numberSevenTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberSevenMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberSevenLabel = new JLabel("What Is the First Justsu that Naruto Masters?");
    ButtonGroup questionNumberSevenButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberSevenChoiceARadioButton = new JRadioButtonMenuItem("A. Rasengan");
    JRadioButtonMenuItem numberSevenChoiceBRadioButton = new JRadioButtonMenuItem("B. Shadow-Clone Justu");
    JRadioButtonMenuItem numberSevenChoiceCRadioButton = new JRadioButtonMenuItem("C. Sage Mode");
    JRadioButtonMenuItem numberSevenChoiceDRadioButton = new JRadioButtonMenuItem("D. Sexy Jutsu");

    JButton numberEightButton = new JButton("8");//Number Eight Question Member Variables
    JFrame numberEightFrame = new JFrame("Anime Guessing Game Question 8");
    JPanel numberEightButtonPanel = new JPanel(new FlowLayout());
    JPanel numberEightTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberEightMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberEightLabel = new JLabel("In 'Hunter X Hunter,' What Was Gon's Hunter Exam Number?");
    ButtonGroup questionNumberEightButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberEightChoiceARadioButton = new JRadioButtonMenuItem("A. 44");
    JRadioButtonMenuItem numberEightChoiceBRadioButton = new JRadioButtonMenuItem("B. 404");
    JRadioButtonMenuItem numberEightChoiceCRadioButton = new JRadioButtonMenuItem("C. 405");
    JRadioButtonMenuItem numberEightChoiceDRadioButton = new JRadioButtonMenuItem("D. 403");

    JButton numberNineButton = new JButton("9");//Number Nine Question Member Variables
    JFrame numberNineFrame = new JFrame("Anime Guessing Game Question 9");
    JPanel numberNineButtonPanel = new JPanel(new FlowLayout());
    JPanel numberNineTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberNineMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberNineLabel = new JLabel("In 'Cowboy Bebop,' What is Spike's Profession?");
    ButtonGroup questionNumberNineButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberNineChoiceARadioButton = new JRadioButtonMenuItem("A. Police Officer");
    JRadioButtonMenuItem numberNineChoiceBRadioButton = new JRadioButtonMenuItem("B. Hit-Man");
    JRadioButtonMenuItem numberNineChoiceCRadioButton = new JRadioButtonMenuItem("C. Bounty Hunter");
    JRadioButtonMenuItem numberNineChoiceDRadioButton = new JRadioButtonMenuItem("D. Hacker");

    JButton numberTenButton = new JButton("10");//Number Ten Question Member Variables
    JFrame numberTenFrame = new JFrame("Anime Guessing Game Question 10");
    JPanel numberTenButtonPanel = new JPanel(new FlowLayout());
    JPanel numberTenTextBoxPanel = new JPanel(new FlowLayout());
    JPanel numberTenMultipleChoicePanel = new JPanel(new FlowLayout());
    JLabel numberTenLabel = new JLabel("The Two Main Characters of 'No Game, No Life,' Sora and Shiro, Together Go By What Username When Gaming?");
    ButtonGroup questionNumberTenButtonGroup = new ButtonGroup();
    JRadioButtonMenuItem numberTenChoiceARadioButton = new JRadioButtonMenuItem("A. 'One True Gods'");
    JRadioButtonMenuItem numberTenChoiceBRadioButton = new JRadioButtonMenuItem("B. The Gods of Games");
    JRadioButtonMenuItem numberTenChoiceCRadioButton = new JRadioButtonMenuItem("C. The King and Queen of Elukia");
    JRadioButtonMenuItem numberTenChoiceDRadioButton = new JRadioButtonMenuItem("D. Blank");

    JFrame informationFrame = new JFrame("Player Information");//Player Information Input Variables
    JPanel informationButtonPanel = new JPanel(new FlowLayout());
    JPanel informationTextBoxPanel = new JPanel(new FlowLayout());
    JLabel firstNameLabel = new JLabel("First Name:");
    JTextField firstNameTextField = new JTextField(20);
    JLabel lastNameLabel = new JLabel("Last Name:");
    JTextField lastNameTextField = new JTextField(20);

    JButton helpButton = new JButton("Help");//Player Information Input Variables
    JFrame helpFrame = new JFrame("Help Instructions");
    JPanel helpButtonPanel = new JPanel(new FlowLayout());
    JPanel helpTextBoxPanel = new JPanel(new FlowLayout());
    JLabel helpLabel = new JLabel("Instructions");
    JLabel helpLabel1 = new JLabel("To play this game, you would need to input your first and last name whether it's your real name or not.");
    JLabel helpLabel2 = new JLabel("There will be 10 questions that are multiple choice and each question is one guess only, so make it count.");
    JLabel helpLabel3 = new JLabel("This is an anime-themed trivia quiz, so if it's not your type of game, don't play it. If you're playing this, then I wish you the best to the game.");

    JButton resultsButton = new JButton("Results");//Game Result Input Variables
    JFrame resultsFrame = new JFrame("Anime Guessing Game Results");
    JPanel resultsButtonPanel = new JPanel(new FlowLayout());
    JPanel resultsTextBoxPanel = new JPanel(new FlowLayout());
    JLabel resultsLabel = new JLabel("Here are Your Results: ");
    JLabel resultsPlayerIDLabel;
    JLabel resultsPlayerFullNameLabel;
    JLabel resultsNumberOfQuestionsCorrectLabel;
    JLabel resultsNumberOfQuestionsInCorrectLabel;

    JButton leaderBoardButton = new JButton("Leader Board");//Game Leader Board Input Variables
    JFrame leaderBoardFrame = new JFrame("Anime Guessing Game Leader Board");
    JPanel leaderBoardButtonPanel = new JPanel(new FlowLayout());
    JPanel leaderBoardTextBoxPanel = new JPanel(new FlowLayout());
    JLabel leaderBoardLabel = new JLabel("2023 Leader Board");
    JLabel leaderBoardPlayerIDLabel;
    JLabel leaderBoardPlayerFullNameLabel;
    JLabel leaderBoardPlayerScore;

    JButton printButton = new JButton("Print Your Score to a File");//Game Print to a File Input Variables
    JFrame printScoreToAFileFrame = new JFrame("Print Your Score To A File");
    JPanel printScoreToAFileButtonPanel = new JPanel(new FlowLayout());
    JPanel printScoreToAFileTextBoxPanel = new JPanel(new FlowLayout());
    JLabel printScoreToAFileLabel = new JLabel("Printing Your Score......... ");
    JButton exitButton = new JButton("Exit");

    public void setUpGui() {//set up frame for the guessing game GUI
        guessingGameFrame.add(guessingGameLabel, BorderLayout.NORTH);
        guessingGameFrame.add(guessingGamePanel, BorderLayout.CENTER);
        guessingGameFrame.addWindowListener(this);
        guessingGameFrame.add(exitButton, BorderLayout.SOUTH);

        guessingGamePanel.setFont(new Font("Helvetica", Font.BOLD, 20));

        guessingGamePanel.add(startButton);
        guessingGamePanel.add(resultsButton);
        guessingGamePanel.add(leaderBoardButton);
        guessingGamePanel.add(helpButton);
        guessingGamePanel.add(printButton);

        guessingGamePanel.setBackground(Color.PINK);

        startButton.setFont(new Font("Helvetica",Font.BOLD,50));
        startButton.setBackground(Color.DARK_GRAY);
        startButton.setForeground(Color.WHITE);

        resultsButton.setFont(new Font("Helvetica",Font.BOLD,50));
        resultsButton.setBackground(Color.DARK_GRAY);
        resultsButton.setForeground(Color.WHITE);

        leaderBoardButton.setFont(new Font("Helvetica",Font.BOLD,50));
        leaderBoardButton.setBackground(Color.DARK_GRAY);
        leaderBoardButton.setForeground(Color.WHITE);

        helpButton.setFont(new Font("Helvetica",Font.BOLD,50));
        helpButton.setBackground(Color.DARK_GRAY);
        helpButton.setForeground(Color.WHITE);

        printButton.setFont(new Font("Helvetica",Font.BOLD,50));
        printButton.setBackground(Color.DARK_GRAY);
        printButton.setForeground(Color.WHITE);

        exitButton.setFont(new Font("Helvetica",Font.BOLD,50));
        exitButton.setBackground(Color.DARK_GRAY);
        exitButton.setForeground(Color.WHITE);

        startButton.addActionListener(new MenuButtonHandler());
        resultsButton.addActionListener(new MenuButtonHandler());
        leaderBoardButton.addActionListener(new MenuButtonHandler());
        helpButton.addActionListener(new MenuButtonHandler());
        printButton.addActionListener(new MenuButtonHandler());
        exitButton.addActionListener(new MenuButtonHandler());

        guessingGameFrame.add(guessingGamePanel);

        guessingGameFrame.pack();
        guessingGameFrame.setSize(1200,700);
        guessingGameFrame.setResizable(false);
        Container c = guessingGameFrame.getContentPane();
        c.setBackground(Color.LIGHT_GRAY);
        guessingGameFrame.setVisible(true);
    }

    public void windowClosing(WindowEvent we) {//method that closes the main menu page
        System.out.println("Shutting Down.....");
        System.exit(0);
    }

    private void startGameWindow() {//sets up the frame for information
        informationFrame = new JFrame("Player Information");
        informationFrame.setDefaultCloseOperation(startFrame.DISPOSE_ON_CLOSE);
        startGameUI(informationFrame);
        informationFrame.setSize(800, 400);
        informationFrame.setLocationRelativeTo(null);
        informationFrame.setResizable(false);
        informationFrame.setVisible(true);
    }

    private void startGameUI(final JFrame informationFrame){//Sets up the labels and text fields for collecting first name and last name with color and button handling
        informationButtonPanel = new JPanel(new FlowLayout());//add back to frame when dispose() get rids of everything
        informationTextBoxPanel = new JPanel(new FlowLayout());
        oKInformationButton= new JButton("OK");
        cancelInformationButton = new JButton("Cancel");
        firstNameLabel = new JLabel("First Name:");
        firstNameTextField = new JTextField(20);
        lastNameLabel = new JLabel("Last Name:");
        lastNameTextField = new JTextField(20);

        informationTextBoxPanel.setLayout(new GridLayout(2, 2));

        informationButtonPanel.add(oKInformationButton);//OK and Cancel buttons gets added to panel
        oKInformationButton.setFont(new Font("Helvetica",Font.BOLD,30));
        informationButtonPanel.add(cancelInformationButton);
        cancelInformationButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKInformationButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKInformationButton.setForeground(Color.WHITE);
        cancelInformationButton.setBackground(Color.DARK_GRAY);//sets color for Cancel button
        cancelInformationButton.setForeground(Color.WHITE);

        oKInformationButton.addActionListener(new OkStartButtonHandler());//sets handlers for OK and Cancel button
        cancelInformationButton.addActionListener(new CancelStartButtonHandler());

        informationButtonPanel.setBackground(Color.PINK);//sets color for panel for button panel

        informationFrame.add(informationButtonPanel);//add button panel to information frame

        informationTextBoxPanel.add(firstNameLabel);//sets color for first name label and text field
        firstNameLabel.setForeground(Color.WHITE);
        firstNameLabel.setFont(new Font("Helvetica",Font.BOLD,20));

        informationTextBoxPanel.add(firstNameTextField);
        firstNameTextField.setBackground(Color.WHITE);

        informationTextBoxPanel.add(lastNameLabel);//sets color for last name label and text field
        lastNameLabel.setForeground(Color.WHITE);
        lastNameLabel.setFont(new Font("Helvetica",Font.BOLD,20));

        informationTextBoxPanel.add(lastNameTextField);
        lastNameTextField.setBackground(Color.WHITE);

        informationTextBoxPanel.setBackground(Color.DARK_GRAY);//sets color for panel for player information text field

        informationFrame.add(informationTextBoxPanel);//add player information text panel to information frame

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, informationTextBoxPanel, informationButtonPanel);//set up split panel for information frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(150);
        informationFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void questionWindow() {//sets up the frame for all questions
        startFrame = new JFrame("Start the Anime Guessing Game");
        startFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        questionUI(startFrame);
        startFrame.setSize(500, 500);
        startFrame.setLocationRelativeTo(null);
        startFrame.setResizable(false);
        startFrame.setVisible(true);
    }

    private void questionUI(final JFrame startFrame) {//Sets up the labels and text fields for questions with color and button handling
        startButtonPanel = new JPanel(new FlowLayout());//add back to frame when dispose() get rids of everything
        oKStartButton= new JButton("OK");
        cancelStartButton = new JButton("Cancel");
        startTextBoxPanel = new JPanel(new FlowLayout());
        numberOneButton = new JButton("1");
        numberTwoButton = new JButton("2");
        numberThreeButton = new JButton("3");
        numberFourButton = new JButton("4");
        numberFiveButton = new JButton("5");
        numberSixButton = new JButton("6");
        numberSevenButton = new JButton("7");
        numberEightButton = new JButton("8");
        numberNineButton = new JButton("9");
        numberTenButton = new JButton("10");

        startFrame.add(startButtonPanel);//add button panel to questions frame
        startButtonPanel.setBackground(Color.PINK);//sets color for panel for open bank account for button panel

        startTextBoxPanel.add(numberOneButton);//sets color for first name label and text field
        numberOneButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberOneButton.setForeground(Color.DARK_GRAY);
        numberOneButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberTwoButton);
        numberTwoButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberTwoButton.setBackground(Color.DARK_GRAY);
        numberTwoButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberThreeButton);//sets color for last name label and text field
        numberThreeButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberThreeButton.setForeground(Color.DARK_GRAY);
        numberThreeButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberFourButton);
        numberFourButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberFourButton.setBackground(Color.DARK_GRAY);
        numberFourButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberFiveButton);
        numberFiveButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberFiveButton.setBackground(Color.DARK_GRAY);
        numberFiveButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberSixButton);
        numberSixButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberSixButton.setBackground(Color.DARK_GRAY);
        numberSixButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberSevenButton);
        numberSevenButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberSevenButton.setBackground(Color.DARK_GRAY);
        numberSevenButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberEightButton);
        numberEightButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberEightButton.setBackground(Color.DARK_GRAY);
        numberEightButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberNineButton);
        numberNineButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberNineButton.setBackground(Color.DARK_GRAY);
        numberNineButton.setBackground(Color.WHITE);

        startTextBoxPanel.add(numberTenButton);
        numberTenButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberTenButton.setBackground(Color.DARK_GRAY);
        numberTenButton.setBackground(Color.WHITE);

        numberOneButton.addActionListener(new NumberOneButtonHandler());
        numberTwoButton.addActionListener(new NumberTwoButtonHandler());
        numberThreeButton.addActionListener(new NumberThreeButtonHandler());
        numberFourButton.addActionListener(new NumberFourButtonHandler());
        numberFiveButton.addActionListener(new NumberFiveButtonHandler());
        numberSixButton.addActionListener(new NumberSixButtonHandler());
        numberSevenButton.addActionListener(new NumberSevenButtonHandler());
        numberEightButton.addActionListener(new NumberEightButtonHandler());
        numberNineButton.addActionListener(new NumberNineButtonHandler());
        numberTenButton.addActionListener(new NumberTenButtonHandler());

        startTextBoxPanel.setBackground(Color.DARK_GRAY);//sets color for panel for

        startFrame.add(startTextBoxPanel);//add open bank account text panel to frame
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, startTextBoxPanel, startButtonPanel);//set up split panel for questions frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(200);
        startFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void numberOneWindow() throws IOException{//sets up the frame for question 1
        numberOneFrame = new JFrame("Anime Guessing Game Question 1");
        numberOneFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberOneUI(numberOneFrame);
        numberOneFrame.setSize(1200, 700);
        numberOneFrame.setLocationRelativeTo(null);
        numberOneFrame.setResizable(false);
        numberOneFrame.setVisible(true);
    }

    private void numberOneUI(JFrame numberOneFrame) throws IOException {//Sets up the labels and text fields for question 1 with color and button handling
        numberOneButtonPanel = new JPanel(new FlowLayout());
        oKNumberOneButton = new JButton("OK");
        cancelNumberOneButton = new JButton("Cancel");

        numberOneTextBoxPanel = new JPanel(new FlowLayout());
        numberOneLabel = new JLabel("What Year Was the First Anime Recorded?");

        BufferedImage questionOnePic = ImageIO.read(new File("src/Question1Pic.jpg"));
        JLabel questionOnePicLabel = new JLabel(new ImageIcon(questionOnePic));

        numberOneMultipleChoicePanel = new JPanel(new FlowLayout());

        numberOneButtonPanel.add(oKNumberOneButton);
        oKNumberOneButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberOneButtonPanel.add(cancelNumberOneButton);
        cancelNumberOneButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberOneButton.addActionListener(new OkNumberOneButtonHandler());//handling for OK and Cancel button
        cancelNumberOneButton.addActionListener(new CancelNumberOneButtonHandler());

        oKNumberOneButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberOneButton.setForeground(Color.WHITE);
        cancelNumberOneButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberOneButton.setForeground(Color.WHITE);

        numberOneFrame.add(numberOneButtonPanel);//add button panel to frame
        numberOneButtonPanel.setBackground(Color.PINK);// sets color for button panel

        questionNumberOneButtonGroup = new ButtonGroup();
        questionNumberOneButtonGroup.add(numberOneChoiceARadioButton);
        questionNumberOneButtonGroup.add(numberOneChoiceBRadioButton);
        questionNumberOneButtonGroup.add(numberOneChoiceCRadioButton);
        questionNumberOneButtonGroup.add(numberOneChoiceDRadioButton);

        numberOneTextBoxPanel.add(numberOneLabel);//add labels to text panel
        numberOneTextBoxPanel.add(questionOnePicLabel);

        numberOneMultipleChoicePanel.add(numberOneChoiceARadioButton);
        numberOneMultipleChoicePanel.add(numberOneChoiceBRadioButton);
        numberOneMultipleChoicePanel.add(numberOneChoiceCRadioButton);
        numberOneMultipleChoicePanel.add(numberOneChoiceDRadioButton);

        numberOneLabel.setForeground(Color.WHITE);
        numberOneLabel.setFont(new Font("Helvetica",Font.BOLD,20));
        numberOneChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberOneChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberOneChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberOneChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberOneChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberOneChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberOneChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberOneChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberOneTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberOneMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberOneFrame.add(numberOneTextBoxPanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberOneTextBoxPanel, numberOneMultipleChoicePanel);//set up split panel for question 1 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberOneFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberOneButtonPanel);//set up split panel for question 1 frame
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberOneFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberTwoWindow() throws IOException{//sets up the frame for question 2
        numberTwoFrame = new JFrame("Anime Guessing Game Question 2");
        numberTwoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberTwoUI(numberTwoFrame);
        numberTwoFrame.setSize(1200, 700);
        numberTwoFrame.setLocationRelativeTo(null);
        numberTwoFrame.setResizable(false);
        numberTwoFrame.setVisible(true);
    }

    private void numberTwoUI(final JFrame numberTwoFrame) throws IOException{//Sets up the labels for question 2 with color and button handling
        numberTwoButtonPanel = new JPanel(new FlowLayout());
        oKNumberTwoButton= new JButton("OK");
        cancelNumberTwoButton = new JButton("Cancel");

        numberTwoTextBoxPanel = new JPanel(new FlowLayout());
        numberTwoLabel = new JLabel("How Many Types of Pokemon Are There?");

        BufferedImage questionTwoPic = ImageIO.read(new File("src/Question2Pic.jpg"));
        JLabel questionTwoPicLabel = new JLabel(new ImageIcon(questionTwoPic));

        numberTwoMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberTwoButtonGroup = new ButtonGroup();
        questionNumberTwoButtonGroup.add(numberTwoChoiceARadioButton);
        questionNumberTwoButtonGroup.add(numberTwoChoiceBRadioButton);
        questionNumberTwoButtonGroup.add(numberTwoChoiceCRadioButton);
        questionNumberTwoButtonGroup.add(numberTwoChoiceDRadioButton);

        numberTwoButtonPanel.add(oKNumberTwoButton);
        oKNumberTwoButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberTwoButtonPanel.add(cancelNumberTwoButton);
        cancelNumberTwoButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberTwoButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberTwoButton.setForeground(Color.WHITE);
        cancelNumberTwoButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberTwoButton.setForeground(Color.WHITE);

        oKNumberTwoButton.addActionListener(new OkNumberTwoButtonHandler());//handling for OK and Cancel button
        cancelNumberTwoButton.addActionListener(new CancelNumberTwoButtonHandler());

        numberTwoFrame.add(numberTwoButtonPanel);//add button panel to frame
        numberTwoButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberTwoTextBoxPanel.add(numberTwoLabel);//add JLabel to text panel
        numberTwoTextBoxPanel.add(questionTwoPicLabel);

        numberTwoMultipleChoicePanel.add(numberTwoChoiceARadioButton);
        numberTwoMultipleChoicePanel.add(numberTwoChoiceBRadioButton);
        numberTwoMultipleChoicePanel.add(numberTwoChoiceCRadioButton);
        numberTwoMultipleChoicePanel.add(numberTwoChoiceDRadioButton);

        numberTwoLabel.setForeground(Color.WHITE);
        numberTwoLabel.setFont(new Font("Helvetica",Font.BOLD,20));
        numberTwoChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberTwoChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberTwoChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberTwoChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberTwoChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberTwoChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberTwoChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberTwoChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberTwoTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberTwoMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberTwoFrame.add(numberTwoTextBoxPanel);
        numberTwoFrame.add(numberTwoMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberTwoTextBoxPanel, numberTwoMultipleChoicePanel);//set up split panel for question 2 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberTwoFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberTwoButtonPanel);
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberTwoFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberThreeWindow() throws IOException{//sets up the frame for question 3 to Bank Account
        numberThreeFrame = new JFrame("Anime Guessing Game Question 3");
        numberThreeFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberThreeUI(numberThreeFrame);
        numberThreeFrame.setSize(1200, 700);
        numberThreeFrame.setLocationRelativeTo(null);
        numberThreeFrame.setResizable(false);
        numberThreeFrame.setVisible(true);
    }

    private void numberThreeUI(final JFrame numberThreeFrame) throws IOException{//Sets up the labels for question 3 with color and button handling
        numberThreeButtonPanel = new JPanel(new FlowLayout());
        oKNumberThreeButton= new JButton("OK");
        cancelNumberThreeButton = new JButton("Cancel");

        numberThreeTextBoxPanel = new JPanel(new FlowLayout());
        numberThreeLabel = new JLabel("Who Has the Nickname of 'One Punch Man'?");

        BufferedImage questionThreePic = ImageIO.read(new File("src/Question3Pic.jpg"));
        JLabel questionThreePicLabel = new JLabel(new ImageIcon(questionThreePic));

        numberThreeMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberThreeButtonGroup = new ButtonGroup();
        numberThreeMultipleChoicePanel.add(numberThreeChoiceARadioButton);
        numberThreeMultipleChoicePanel.add(numberThreeChoiceBRadioButton);
        numberThreeMultipleChoicePanel.add(numberThreeChoiceCRadioButton);
        numberThreeMultipleChoicePanel.add(numberThreeChoiceDRadioButton);

        numberThreeButtonPanel.add(oKNumberThreeButton);
        oKNumberThreeButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberThreeButtonPanel.add(cancelNumberThreeButton);
        cancelNumberThreeButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberThreeButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberThreeButton.setForeground(Color.WHITE);
        cancelNumberThreeButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberThreeButton.setForeground(Color.WHITE);

        oKNumberThreeButton.addActionListener(new OkNumberThreeButtonHandler());//handling for OK and Cancel button
        cancelNumberThreeButton.addActionListener(new CancelNumberThreeButtonHandler());

        numberThreeFrame.add(numberThreeButtonPanel);//add button panel to frame
        numberThreeButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberThreeTextBoxPanel.add(numberThreeLabel);//add deposit JLabel to text panel
        numberThreeTextBoxPanel.add(questionThreePicLabel);

        numberThreeMultipleChoicePanel.add(numberThreeChoiceARadioButton);
        numberThreeMultipleChoicePanel.add(numberThreeChoiceBRadioButton);
        numberThreeMultipleChoicePanel.add(numberThreeChoiceCRadioButton);
        numberThreeMultipleChoicePanel.add(numberThreeChoiceDRadioButton);

        numberThreeLabel.setForeground(Color.WHITE);
        numberThreeLabel.setFont(new Font("Helvetica",Font.BOLD,20));
        numberThreeChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberThreeChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberThreeChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberThreeChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberThreeChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberThreeChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberThreeChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberThreeChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberThreeTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberThreeMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberThreeFrame.add(numberThreeTextBoxPanel);
        numberThreeFrame.add(numberThreeMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberThreeTextBoxPanel, numberThreeMultipleChoicePanel);//set up split panel for question 3 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberThreeFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberThreeButtonPanel);
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberThreeFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberFourWindow() throws IOException {//sets up the frame for question 4
        numberFourFrame = new JFrame("Anime Guessing Game Question 4");
        numberFourFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberFourUI(numberFourFrame);
        numberFourFrame.setSize(1200, 700);
        numberFourFrame.setLocationRelativeTo(null);
        numberFourFrame.setResizable(false);
        numberFourFrame.setVisible(true);
    }

    private void numberFourUI(final JFrame numberFourFrame) throws IOException{//Sets up the labels for question 4 with color and button handling
        numberFourButtonPanel = new JPanel(new FlowLayout());
        oKNumberFourButton= new JButton("OK");
        cancelNumberFourButton = new JButton("Cancel");

        numberFourTextBoxPanel = new JPanel(new FlowLayout());
        numberFourLabel = new JLabel("How Many Dragon Balls Are There?");

        BufferedImage questionFourPic = ImageIO.read(new File("src/Question4Pic.jpg"));
        JLabel questionFourPicLabel = new JLabel(new ImageIcon(questionFourPic));

        numberFourMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberFourButtonGroup = new ButtonGroup();
        questionNumberFourButtonGroup.add(numberFourChoiceARadioButton);
        questionNumberFourButtonGroup.add(numberFourChoiceBRadioButton);
        questionNumberFourButtonGroup.add(numberFourChoiceCRadioButton);
        questionNumberFourButtonGroup.add(numberFourChoiceDRadioButton);

        numberFourButtonPanel.add(oKNumberFourButton);
        oKNumberFourButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberFourButtonPanel.add(cancelNumberFourButton);
        cancelNumberFourButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberFourButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberFourButton.setForeground(Color.WHITE);
        cancelNumberFourButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberFourButton.setForeground(Color.WHITE);

        oKNumberFourButton.addActionListener(new OkNumberFourButtonHandler());//handling for OK and Cancel button
        cancelNumberFourButton.addActionListener(new CancelNumberFourButtonHandler());

        numberFourFrame.add(numberFourButtonPanel);//add button panel to frame
        numberFourButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberFourTextBoxPanel.add(numberFourLabel);//add deposit JLabel to text panel
        numberFourTextBoxPanel.add(questionFourPicLabel);

        numberFourMultipleChoicePanel.add(numberFourChoiceARadioButton);
        numberFourMultipleChoicePanel.add(numberFourChoiceBRadioButton);
        numberFourMultipleChoicePanel.add(numberFourChoiceCRadioButton);
        numberFourMultipleChoicePanel.add(numberFourChoiceDRadioButton);

        numberFourLabel.setForeground(Color.WHITE);
        numberFourLabel.setFont(new Font("Helvetica",Font.BOLD,20));
        numberFourChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberFourChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberFourChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberFourChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberFourChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberFourChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberFourChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberFourChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberFourTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberFourMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberFourFrame.add(numberFourTextBoxPanel);
        numberFourFrame.add(numberFourMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberFourTextBoxPanel, numberFourMultipleChoicePanel);//set up split panel for question 4 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberFourFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberFourButtonPanel);
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberFourFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberFiveWindow() throws IOException {//sets up the frame for question 5
        numberFiveFrame = new JFrame("Anime Guessing Game Question 5");
        numberFiveFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberFiveUI(numberFiveFrame);
        numberFiveFrame.setSize(1200, 700);
        numberFiveFrame.setLocationRelativeTo(null);
        numberFiveFrame.setResizable(false);
        numberFiveFrame.setVisible(true);
    }

    private void numberFiveUI(JFrame numberFiveFrame) throws IOException {//Sets up the labels for question 5 with color and button handling
        numberFiveButtonPanel = new JPanel(new FlowLayout());
        numberFiveTextBoxPanel = new JPanel(new FlowLayout());
        numberFiveLabel = new JLabel("'Haikyuu!!' Is An Anime Centered Around A Boy Who Wants To Be Successful in Which Sport?");
        questionNumberFiveButtonGroup = new ButtonGroup();

        BufferedImage questionFivePic = ImageIO.read(new File("src/Question5Pic.jpg"));
        JLabel questionFivePicLabel = new JLabel(new ImageIcon(questionFivePic));

        numberFiveButtonPanel.add(oKNumberFiveButton);
        oKNumberFiveButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberFiveButtonPanel.add(cancelNumberFiveButton);
        cancelNumberFiveButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberFiveButton.addActionListener(new OkNumberFiveButtonHandler());//handling for OK and Cancel button
        cancelNumberFiveButton.addActionListener(new CancelNumberFiveButtonHandler());

        oKNumberFiveButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberFiveButton.setForeground(Color.WHITE);
        cancelNumberFiveButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberFiveButton.setForeground(Color.WHITE);

        numberFiveFrame.add(numberFiveButtonPanel);//add button panel to frame
        numberFiveButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberFiveMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberFiveButtonGroup = new ButtonGroup();
        questionNumberFiveButtonGroup.add(numberFiveChoiceARadioButton);
        questionNumberFiveButtonGroup.add(numberFiveChoiceBRadioButton);
        questionNumberFiveButtonGroup.add(numberFiveChoiceCRadioButton);
        questionNumberFiveButtonGroup.add(numberFiveChoiceDRadioButton);

        numberFiveTextBoxPanel.add(numberFiveLabel);//add labels to text panel
        numberFiveTextBoxPanel.add(questionFivePicLabel);

        numberFiveMultipleChoicePanel.add(numberFiveChoiceARadioButton);
        numberFiveMultipleChoicePanel.add(numberFiveChoiceBRadioButton);
        numberFiveMultipleChoicePanel.add(numberFiveChoiceCRadioButton);
        numberFiveMultipleChoicePanel.add(numberFiveChoiceDRadioButton);

        numberFiveLabel.setForeground(Color.WHITE);
        numberFiveLabel.setFont(new Font("Helvetica",Font.BOLD,13));
        numberFiveChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberFiveChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberFiveChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberFiveChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberFiveChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberFiveChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberFiveChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberFiveChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberFiveTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberFiveMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberFiveFrame.add(numberFiveTextBoxPanel);
        numberFiveFrame.add(numberFiveMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberFiveTextBoxPanel, numberFiveMultipleChoicePanel);//set up split panel for question 5 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberFiveFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberFiveButtonPanel);//set up split panel for question 5 frame
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberFiveFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberSixWindow() throws IOException {//sets up the frame for question 6
        numberSixFrame = new JFrame("Anime Guessing Game Question 6");
        numberSixFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberSixUI(numberSixFrame);
        numberSixFrame.setSize(1200, 700);
        numberSixFrame.setLocationRelativeTo(null);
        numberSixFrame.setResizable(false);
        numberSixFrame.setVisible(true);
    }

    private void numberSixUI(JFrame numberSixFrame) throws IOException{//Sets up the labels for question 6 with color and button handling
        numberSixButtonPanel = new JPanel(new FlowLayout());
        numberSixTextBoxPanel = new JPanel(new FlowLayout());
        numberSixLabel = new JLabel("In Noragami, Yato Is the God of What?");

        BufferedImage questionSixPic = ImageIO.read(new File("src/Question6Pic.jpg"));
        JLabel questionSixPicLabel = new JLabel(new ImageIcon(questionSixPic));

        oKNumberSixButton = new JButton("OK");
        cancelNumberSixButton = new JButton("Cancel");

        numberSixButtonPanel.add(oKNumberSixButton);
        oKNumberSixButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberSixButtonPanel.add(cancelNumberSixButton);
        cancelNumberSixButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberSixButton.addActionListener(new OkNumberSixButtonHandler());//handling for OK and Cancel button
        cancelNumberSixButton.addActionListener(new CancelNumberSixButtonHandler());

        oKNumberSixButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberSixButton.setForeground(Color.WHITE);
        cancelNumberSixButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberSixButton.setForeground(Color.WHITE);

        numberSixFrame.add(numberSixButtonPanel);//add button panel to frame
        numberSixButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberSixMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberSixButtonGroup = new ButtonGroup();
        questionNumberSixButtonGroup.add(numberSixChoiceARadioButton);
        questionNumberSixButtonGroup.add(numberSixChoiceBRadioButton);
        questionNumberSixButtonGroup.add(numberSixChoiceCRadioButton);
        questionNumberSixButtonGroup.add(numberSixChoiceDRadioButton);

        numberSixTextBoxPanel.add(numberSixLabel);//add labels to text panel
        numberSixTextBoxPanel.add(questionSixPicLabel);

        numberSixMultipleChoicePanel.add(numberSixChoiceARadioButton);
        numberSixMultipleChoicePanel.add(numberSixChoiceBRadioButton);
        numberSixMultipleChoicePanel.add(numberSixChoiceCRadioButton);
        numberSixMultipleChoicePanel.add(numberSixChoiceDRadioButton);

        numberSixLabel.setForeground(Color.WHITE);
        numberSixLabel.setFont(new Font("Helvetica",Font.BOLD,20));
        numberSixChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberSixChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberSixChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberSixChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberSixChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberSixChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberSixChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberSixChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberSixTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberSixMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberSixFrame.add(numberSixTextBoxPanel);
        numberSixFrame.add(numberSixMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberSixTextBoxPanel, numberSixMultipleChoicePanel);//set up split panel for question 6 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberSixFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberSixButtonPanel);//set up split panel for question 6 frame
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberSixFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberSevenWindow() throws IOException {//sets up the frame for question 7
        numberSevenFrame = new JFrame("Anime Guessing Game Question 7");
        numberSevenFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberSevenUI(numberSevenFrame);
        numberSevenFrame.setSize(1200, 700);
        numberSevenFrame.setLocationRelativeTo(null);
        numberSevenFrame.setResizable(false);
        numberSevenFrame.setVisible(true);
    }

    private void numberSevenUI(JFrame numberSevenFrame) throws IOException{//Sets up the labels for question 7 with color and button handling
        numberSevenButtonPanel = new JPanel(new FlowLayout());
        numberSevenTextBoxPanel = new JPanel(new FlowLayout());

        oKNumberSevenButton = new JButton("OK");
        cancelNumberSevenButton = new JButton("Cancel");
        numberSevenLabel = new JLabel("What Is the First Justsu that Naruto Masters and Uses at the End of the First Episode?");

        BufferedImage questionSevenPic = ImageIO.read(new File("src/Question7Pic.jpg"));
        JLabel questionSevenPicLabel = new JLabel(new ImageIcon(questionSevenPic));

        numberSevenButtonPanel.add(oKNumberSevenButton);
        oKNumberSevenButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberSevenButtonPanel.add(cancelNumberSevenButton);
        cancelNumberSevenButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberSevenButton.addActionListener(new OkNumberSevenButtonHandler());//handling for OK and Cancel button
        cancelNumberSevenButton.addActionListener(new CancelNumberSevenButtonHandler());

        oKNumberSevenButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberSevenButton.setForeground(Color.WHITE);
        cancelNumberSevenButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberSevenButton.setForeground(Color.WHITE);

        numberSevenFrame.add(numberSevenButtonPanel);//add button panel to frame
        numberSevenButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberSevenMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberSevenButtonGroup = new ButtonGroup();
        questionNumberSevenButtonGroup.add(numberSevenChoiceARadioButton);
        questionNumberSevenButtonGroup.add(numberSevenChoiceBRadioButton);
        questionNumberSevenButtonGroup.add(numberSevenChoiceCRadioButton);
        questionNumberSevenButtonGroup.add(numberSevenChoiceDRadioButton);

        numberSevenTextBoxPanel.add(numberSevenLabel);//add labels to text panel
        numberSevenTextBoxPanel.add(questionSevenPicLabel);

        numberSevenMultipleChoicePanel.add(numberSevenChoiceARadioButton);
        numberSevenMultipleChoicePanel.add(numberSevenChoiceBRadioButton);
        numberSevenMultipleChoicePanel.add(numberSevenChoiceCRadioButton);
        numberSevenMultipleChoicePanel.add(numberSevenChoiceDRadioButton);

        numberSevenLabel.setForeground(Color.WHITE);
        numberSevenLabel.setFont(new Font("Helvetica",Font.BOLD,13));
        numberSevenChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberSevenChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,40));
        numberSevenChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberSevenChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,40));
        numberSevenChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberSevenChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,40));
        numberSevenChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberSevenChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,40));

        numberSevenTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberSevenMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberSevenFrame.add(numberSevenTextBoxPanel);
        numberSevenFrame.add(numberSevenMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberSevenTextBoxPanel, numberSevenMultipleChoicePanel);//set up split panel for question 7 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberSevenFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberSevenButtonPanel);//set up split panel for question 7 frame
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberSevenFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberEightWindow() throws IOException {//sets up the frame for question 8
        numberEightFrame = new JFrame("Anime Guessing Game Question 8");
        numberEightFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberEightUI(numberEightFrame);
        numberEightFrame.setSize(1200, 700);
        numberEightFrame.setLocationRelativeTo(null);
        numberEightFrame.setResizable(false);
        numberEightFrame.setVisible(true);
    }

    private void numberEightUI(JFrame numberEightFrame) throws IOException {//Sets up labels for question 8 with color and button handling
        numberEightButtonPanel = new JPanel(new FlowLayout());
        numberEightTextBoxPanel = new JPanel(new FlowLayout());
        numberEightLabel = new JLabel("In 'Hunter X Hunter,' What Was Gon's Hunter Exam Number?");

        BufferedImage questionEightPic = ImageIO.read(new File("src/Question8Pic.jpg"));
        JLabel questionEightPicLabel = new JLabel(new ImageIcon(questionEightPic));

        numberEightButtonPanel.add(oKNumberEightButton);
        oKNumberEightButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberEightButtonPanel.add(cancelNumberEightButton);
        cancelNumberEightButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberEightButton.addActionListener(new OkNumberEightButtonHandler());//handling for OK and Cancel button
        cancelNumberEightButton.addActionListener(new CancelNumberEightButtonHandler());

        oKNumberEightButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberEightButton.setForeground(Color.WHITE);
        cancelNumberEightButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberEightButton.setForeground(Color.WHITE);

        numberEightFrame.add(numberEightButtonPanel);//add button panel to frame
        numberEightButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberEightMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberEightButtonGroup = new ButtonGroup();
        questionNumberEightButtonGroup.add(numberEightChoiceARadioButton);
        questionNumberEightButtonGroup.add(numberEightChoiceBRadioButton);
        questionNumberEightButtonGroup.add(numberEightChoiceCRadioButton);
        questionNumberEightButtonGroup.add(numberEightChoiceDRadioButton);

        numberEightTextBoxPanel.add(numberEightLabel);//add labels to text panel
        numberEightTextBoxPanel.add(questionEightPicLabel);

        numberEightMultipleChoicePanel.add(numberEightChoiceARadioButton);
        numberEightMultipleChoicePanel.add(numberEightChoiceBRadioButton);
        numberEightMultipleChoicePanel.add(numberEightChoiceCRadioButton);
        numberEightMultipleChoicePanel.add(numberEightChoiceDRadioButton);

        numberEightLabel.setForeground(Color.WHITE);
        numberEightLabel.setFont(new Font("Helvetica",Font.BOLD,20));
        numberEightChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberEightChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberEightChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberEightChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberEightChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberEightChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberEightChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberEightChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberEightTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberEightMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberEightFrame.add(numberEightTextBoxPanel);
        numberEightFrame.add(numberEightMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberEightTextBoxPanel, numberEightMultipleChoicePanel);//set up split panel for question 8 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberEightFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberEightButtonPanel);//set up split panel for question 8 frame
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberEightFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberNineWindow() throws IOException {//sets up the frame for question 9
        numberNineFrame = new JFrame("Anime Guessing Game Question 9");
        numberNineFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberNineUI(numberNineFrame);
        numberNineFrame.setSize(1200, 700);
        numberNineFrame.setLocationRelativeTo(null);
        numberNineFrame.setResizable(false);
        numberNineFrame.setVisible(true);
    }

    private void numberNineUI(JFrame numberNineFrame) throws IOException {//Sets up the labels and text fields for question 9 with color and button handling
        numberNineButtonPanel = new JPanel(new FlowLayout());
        numberNineTextBoxPanel = new JPanel(new FlowLayout());
        numberNineLabel = new JLabel("In 'Cowboy Bebop,' What is Spike's Profession?");

        BufferedImage questionNinePic = ImageIO.read(new File("src/Question9Pic.jpg"));
        JLabel questionNinePicLabel = new JLabel(new ImageIcon(questionNinePic));

        numberNineButtonPanel.add(oKNumberNineButton);
        oKNumberNineButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberNineButtonPanel.add(cancelNumberNineButton);
        cancelNumberNineButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberNineButton.addActionListener(new OkNumberNineButtonHandler());//handling for OK and Cancel button
        cancelNumberNineButton.addActionListener(new CancelNumberNineButtonHandler());

        oKNumberNineButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberNineButton.setForeground(Color.WHITE);
        cancelNumberNineButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberNineButton.setForeground(Color.WHITE);

        numberNineFrame.add(numberNineButtonPanel);//add button panel to frame
        numberNineButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberNineMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberNineButtonGroup = new ButtonGroup();
        questionNumberNineButtonGroup.add(numberNineChoiceARadioButton);
        questionNumberNineButtonGroup.add(numberNineChoiceBRadioButton);
        questionNumberNineButtonGroup.add(numberEightChoiceCRadioButton);
        questionNumberNineButtonGroup.add(numberEightChoiceDRadioButton);

        numberNineTextBoxPanel.add(numberNineLabel);//add labels to text panel
        numberNineTextBoxPanel.add(questionNinePicLabel);

        numberNineMultipleChoicePanel.add(numberNineChoiceARadioButton);
        numberNineMultipleChoicePanel.add(numberNineChoiceBRadioButton);
        numberNineMultipleChoicePanel.add(numberNineChoiceCRadioButton);
        numberNineMultipleChoicePanel.add(numberNineChoiceDRadioButton);

        numberNineLabel.setForeground(Color.WHITE);
        numberNineLabel.setFont(new Font("Helvetica",Font.BOLD,20));
        numberNineChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberNineChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberNineChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberNineChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberNineChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberNineChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));
        numberNineChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberNineChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,50));

        numberNineTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberNineMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberNineFrame.add(numberNineTextBoxPanel);
        numberNineFrame.add(numberNineMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberNineTextBoxPanel, numberNineMultipleChoicePanel);//set up split panel for question 9 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(600);
        numberNineFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberNineButtonPanel);//set up split panel for question 9 frame
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberNineFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void numberTenWindow() throws IOException {//sets up the frame for question 9
        numberTenFrame = new JFrame("Anime Guessing Game Question 10");
        numberTenFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberTenUI(numberTenFrame);
        numberTenFrame.setSize(1200, 700);
        numberTenFrame.setLocationRelativeTo(null);
        numberTenFrame.setResizable(false);
        numberTenFrame.setVisible(true);
    }

    private void numberTenUI(JFrame numberTenFrame) throws IOException {//Sets up the labels for question 10 with color and button handling
        numberTenButtonPanel = new JPanel(new FlowLayout());
        numberTenTextBoxPanel = new JPanel(new FlowLayout());
        numberTenLabel = new JLabel("The Two Main Characters of 'No Game, No Life,' Sora and Shiro, Together Go By What Username When Gaming?");

        BufferedImage questionTenPic = ImageIO.read(new File("src/Question10Pic.jpg"));
        JLabel questionTenPicLabel = new JLabel(new ImageIcon(questionTenPic));

        numberTenButtonPanel.add(oKNumberTenButton);
        oKNumberTenButton.setFont(new Font("Helvetica",Font.BOLD,30));
        numberTenButtonPanel.add(cancelNumberTenButton);
        cancelNumberTenButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKNumberTenButton.addActionListener(new OkNumberTenButtonHandler());//handling for OK and Cancel button
        cancelNumberTenButton.addActionListener(new CancelNumberTenButtonHandler());

        oKNumberTenButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKNumberTenButton.setForeground(Color.WHITE);
        cancelNumberTenButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberTenButton.setForeground(Color.WHITE);

        numberTenFrame.add(numberTenButtonPanel);//add button panel to frame
        numberTenButtonPanel.setBackground(Color.PINK);// sets color for button panel

        numberTenMultipleChoicePanel = new JPanel(new FlowLayout());
        questionNumberTenButtonGroup = new ButtonGroup();
        questionNumberTenButtonGroup.add(numberTenChoiceARadioButton);
        questionNumberTenButtonGroup.add(numberTenChoiceBRadioButton);
        questionNumberTenButtonGroup.add(numberTenChoiceCRadioButton);
        questionNumberTenButtonGroup.add(numberTenChoiceDRadioButton);

        numberTenTextBoxPanel.add(numberTenLabel);//add labels to text panel
        numberTenTextBoxPanel.add(questionTenPicLabel);

        numberTenMultipleChoicePanel.add(numberTenChoiceARadioButton);
        numberTenMultipleChoicePanel.add(numberTenChoiceBRadioButton);
        numberTenMultipleChoicePanel.add(numberTenChoiceCRadioButton);
        numberTenMultipleChoicePanel.add(numberTenChoiceDRadioButton);

        numberTenLabel.setForeground(Color.WHITE);
        numberTenLabel.setFont(new Font("Helvetica",Font.BOLD,15));
        numberTenChoiceARadioButton.setForeground(Color.DARK_GRAY);
        numberTenChoiceARadioButton.setFont(new Font("Helvetica",Font.BOLD,20));
        numberTenChoiceBRadioButton.setForeground(Color.DARK_GRAY);
        numberTenChoiceBRadioButton.setFont(new Font("Helvetica",Font.BOLD,20));
        numberTenChoiceCRadioButton.setForeground(Color.DARK_GRAY);
        numberTenChoiceCRadioButton.setFont(new Font("Helvetica",Font.BOLD,20));
        numberTenChoiceDRadioButton.setForeground(Color.DARK_GRAY);
        numberTenChoiceDRadioButton.setFont(new Font("Helvetica",Font.BOLD,20));

        numberTenTextBoxPanel.setBackground(Color.DARK_GRAY);
        numberTenMultipleChoicePanel.setBackground(Color.DARK_GRAY);

        numberTenFrame.add(numberTenTextBoxPanel);
        numberTenFrame.add(numberTenMultipleChoicePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, numberTenTextBoxPanel, numberTenMultipleChoicePanel);//set up split panel for question 10 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(800);
        numberTenFrame.getContentPane().add(splitPane, BorderLayout.CENTER);

        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, numberTenButtonPanel);//set up split panel for question 10 frame
        splitPane1.setOneTouchExpandable(true);
        splitPane1.setDividerLocation(350);
        numberTenFrame.getContentPane().add(splitPane1, BorderLayout.CENTER);
    }

    private void helpWindow() {//sets up the frame for help
        helpFrame = new JFrame("Help Instructions");
        helpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        helpUI(helpFrame);
        helpFrame.setSize(1200, 500);
        helpFrame.setLocationRelativeTo(null);
        helpFrame.setResizable(false);
        helpFrame.setVisible(true);
    }

    private void helpUI(final JFrame helpFrame){//Sets up the labels and text fields for help with color and button handling
        helpButtonPanel = new JPanel(new FlowLayout());
        oKHelpButton = new JButton("OK");
        helpTextBoxPanel = new JPanel(new FlowLayout());
        helpLabel = new JLabel("Instructions");
        helpLabel1 = new JLabel("To play this game, you would need to input your first and last name whether it's your real name or not.");
        helpLabel2 = new JLabel("There will be 10 questions that are multiple choice and each question is one guess only, so make it count.");
        helpLabel3 = new JLabel("This is an anime-themed trivia quiz, so if it's not your type of game, don't play it. If you're playing this, then I wish you the best to the game.");

        helpButtonPanel.add(oKHelpButton);

        oKHelpButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKHelpButton.setForeground(Color.WHITE);

        oKHelpButton.addActionListener(new OkHelpButtonHandler());//handling for OK and Cancel button
        oKHelpButton.setFont(new Font("Helvetica",Font.BOLD,30));

        helpFrame.add(helpButtonPanel);//add button panel to frame
        helpButtonPanel.setBackground(Color.PINK);// sets color for button panel

        helpTextBoxPanel.add(helpLabel);//add helpLabel JLabel to text panel
        helpLabel.setForeground(Color.WHITE);// sets color for helpLabel JLabel
        helpTextBoxPanel.add(helpLabel1);//add helpLabel1 JLabel to text panel
        helpLabel1.setForeground(Color.WHITE);//sets color for helpLabel1 JLabel
        helpTextBoxPanel.add(helpLabel2);//add helpLabel2 JLabel to text panel
        helpLabel2.setForeground(Color.WHITE);//sets color for helpLabel2 JLabel
        helpTextBoxPanel.add(helpLabel3);//add helpLabel3 JLabel to text panel
        helpLabel3.setForeground(Color.WHITE);// sets color for helpLabel3 JLabel

        helpTextBoxPanel.setBackground(Color.DARK_GRAY);//set color to text panel

        helpFrame.add(helpTextBoxPanel);//add text panel to frame

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, helpTextBoxPanel, helpButtonPanel);//set up split panel for help
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(200);
        helpFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void resultsWindow() {//had an issue with loading the window and pops up print score to file window as well
        resultsFrame = new JFrame("Anime Guessing Game Results");
        resultsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        resultsUI(resultsFrame);
        resultsFrame.setSize(1200, 700);
        resultsFrame.setLocationRelativeTo(null);
        resultsFrame.setResizable(false);
        resultsFrame.setVisible(true);
    }

    private void resultsUI(final JFrame resultsFrame){//Sets up the labels and text fields for deposit with color and button handling
        resultsButtonPanel = new JPanel(new FlowLayout());
        resultsTextBoxPanel = new JPanel(new FlowLayout());
        resultsLabel = new JLabel("Here are Your Results: ");
        oKResultsButton = new JButton("OK");

        resultsButtonPanel.add(oKResultsButton);
        oKResultsButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKResultsButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKResultsButton.setForeground(Color.WHITE);

        oKResultsButton.addActionListener(new OkResultsButtonHandler());//handling for OK and Cancel button

        resultsFrame.add(resultsButtonPanel);//add button panel to frame
        resultsButtonPanel.setBackground(Color.PINK);// sets color for button panel

        resultsTextBoxPanel.add(resultsLabel);//add deposit JLabel to deposit text panel
        resultsLabel.setForeground(Color.WHITE);// sets color for deposit label and text field

        resultsTextBoxPanel.setBackground(Color.DARK_GRAY);

        resultsPlayerIDLabel = new JLabel("ID: " + playerObject.getPlayerID());
        resultsPlayerFullNameLabel = new JLabel("Player's Name: " + playerObject.getPlayer());
        resultsNumberOfQuestionsCorrectLabel = new JLabel("Number of Correct Answers: " + playerObject.getGameScore());
        resultsNumberOfQuestionsInCorrectLabel = new JLabel("Number of Questions Left: " + (10 - numberOfQuestionsAnswered));

        resultsTextBoxPanel.add(resultsPlayerIDLabel);
        resultsTextBoxPanel.add(resultsPlayerFullNameLabel);
        resultsTextBoxPanel.add(resultsNumberOfQuestionsCorrectLabel);
        resultsTextBoxPanel.add(resultsNumberOfQuestionsInCorrectLabel);

        resultsPlayerIDLabel.setForeground(Color.WHITE);
        resultsPlayerFullNameLabel.setForeground(Color.WHITE);
        resultsNumberOfQuestionsCorrectLabel.setForeground(Color.WHITE);
        resultsNumberOfQuestionsInCorrectLabel.setForeground(Color.WHITE);

        resultsFrame.add(resultsTextBoxPanel);//sets color for panel for open bank account text field

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, resultsTextBoxPanel, resultsButtonPanel);//set up split panel for open bank account frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(350);
        resultsFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void leaderBoardWindow() {//sets up the frame for leader board and had an issue with loading the window and pops up print score to file window as well
        leaderBoardFrame = new JFrame("Anime Guessing Game Leader Board");
        leaderBoardFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        leaderBoardUI(leaderBoardFrame);
        leaderBoardFrame.setSize(1200, 700);
        leaderBoardFrame.setLocationRelativeTo(null);
        leaderBoardFrame.setResizable(false);
        leaderBoardFrame.setVisible(true);
    }

    private void leaderBoardUI(final JFrame leaderBoardFrame) {//Sets up the labels and text fields for leader board with color and button handling
        leaderBoardButtonPanel = new JPanel(new FlowLayout());
        leaderBoardTextBoxPanel = new JPanel(new FlowLayout());
        leaderBoardLabel = new JLabel("2023 Leader Board");
        oKLeaderBoardButton = new JButton("OK");

        for (Player_AN player : playerList) {
            leaderBoardPlayerIDLabel = new JLabel("ID: " + player.getPlayerID());
            leaderBoardPlayerFullNameLabel = new JLabel("PLayer's Name: " + player.getPlayer());
            leaderBoardPlayerScore = new JLabel("Score: " + player.getGameScore());

            leaderBoardButtonPanel.add(oKLeaderBoardButton);
            oKLeaderBoardButton.setFont(new Font("Helvetica", Font.BOLD, 30));

            oKLeaderBoardButton.setBackground(Color.DARK_GRAY);//sets color for OK button
            oKLeaderBoardButton.setForeground(Color.WHITE);

            oKLeaderBoardButton.addActionListener(new OkLeaderBoardButtonHandler());//handling for OK and Cancel button

            leaderBoardFrame.add(leaderBoardButtonPanel);//add button panel to frame
            leaderBoardButtonPanel.setBackground(Color.PINK);// sets color for button panel

            leaderBoardTextBoxPanel.add(leaderBoardLabel);//add deposit JLabel to deposit text panel
            leaderBoardLabel.setForeground(Color.WHITE);// sets color for deposit label and text field

            leaderBoardTextBoxPanel.add(leaderBoardPlayerIDLabel);
            leaderBoardPlayerIDLabel.setForeground(Color.WHITE);
            leaderBoardTextBoxPanel.add(leaderBoardPlayerFullNameLabel);
            leaderBoardPlayerFullNameLabel.setForeground(Color.WHITE);
            leaderBoardTextBoxPanel.add(leaderBoardPlayerScore);
            leaderBoardPlayerScore.setForeground(Color.WHITE);

            leaderBoardTextBoxPanel.setBackground(Color.DARK_GRAY);

            JLabel lineBreak = new JLabel("--------------------------------");
            leaderBoardTextBoxPanel.add(lineBreak);
            lineBreak.setForeground(Color.WHITE);
            lineBreak.setFont(new Font("Helvetica", Font.BOLD, 30));

            leaderBoardFrame.add(leaderBoardTextBoxPanel);//sets color for panel for open bank account text field
        }

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, leaderBoardTextBoxPanel, leaderBoardButtonPanel);//set up split panel for open bank account frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(350);
        leaderBoardFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void printScoreToAFileWindow() {// " "
        printScoreToAFileFrame = new JFrame("Print Your Score To A File");
        printScoreToAFileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        printScoreToAFileUI(printScoreToAFileFrame);
        printScoreToAFileFrame.setSize(600, 300);
        printScoreToAFileFrame.setLocationRelativeTo(null);
        printScoreToAFileFrame.setResizable(false);
        printScoreToAFileFrame.setVisible(true);
    }

    private void printScoreToAFileUI(final JFrame printScoreToAFileFrame) {//Sets up the labels for window to show printing to text with color and button handling
        printScoreToAFileButtonPanel = new JPanel(new FlowLayout());
        printScoreToAFileTextBoxPanel = new JPanel(new FlowLayout());
        oKPrintScoreToAFileButton = new JButton("OK");
        cancelPrintScoreToAFileButton = new JButton("Cancel");
        printScoreToAFileLabel = new JLabel("Printing Your Score......... ");

        printScoreToAFileButtonPanel.add(oKPrintScoreToAFileButton);//" "
        oKPrintScoreToAFileButton.setFont(new Font("Helvetica",Font.BOLD,30));
        printScoreToAFileButtonPanel.add(cancelPrintScoreToAFileButton);
        cancelPrintScoreToAFileButton.setFont(new Font("Helvetica",Font.BOLD,30));

        oKPrintScoreToAFileButton.setBackground(Color.DARK_GRAY);//" "
        oKPrintScoreToAFileButton.setForeground(Color.WHITE);
        cancelPrintScoreToAFileButton.setBackground(Color.DARK_GRAY);//" "
        cancelPrintScoreToAFileButton.setForeground(Color.WHITE);

        oKPrintScoreToAFileButton.addActionListener(new OkPrintScoreToAFileButtonHandler());//" "
        cancelPrintScoreToAFileButton.addActionListener(new CancelPrintScoreToAFileButtonHandler());

        printScoreToAFileFrame.add(printScoreToAFileButtonPanel);//" "
        printScoreToAFileButtonPanel.setBackground(Color.PINK);

        printScoreToAFileTextBoxPanel.add(printScoreToAFileLabel);//" "
        printScoreToAFileLabel.setForeground(Color.WHITE);

        printScoreToAFileTextBoxPanel.setBackground(Color.DARK_GRAY);


        printScoreToAFileFrame.add(printScoreToAFileTextBoxPanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, printScoreToAFileTextBoxPanel, printScoreToAFileButtonPanel);//set up split panel for print statement activities frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        printScoreToAFileFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    public class MenuButtonHandler implements  ActionListener {//button handler for menu screen when opening GUI
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("MenuButtonHandler " + command);

            switch(command) {
                case "Start":
                    if (gameInProgress) {
                        JOptionPane.showMessageDialog(null, "A Game is in Progress. You will need to wait for your turn.", "Warning", JOptionPane.ERROR_MESSAGE);
                    } else {
                        startGameWindow();
                    }
                    break;
                case "Help":
                    helpWindow();
                    break;
                case "Results":
                    if (playerObject == null) {
                        JOptionPane.showMessageDialog(null, "Please Enter Your Name Before Continuing.", "Warning", JOptionPane.ERROR_MESSAGE);
                    } else {
                        resultsWindow();
                    }
                    break;
                case "Leader Board":
                    if (playerObject == null) {
                        JOptionPane.showMessageDialog(null, "Please Enter Your Name Before Continuing.", "Warning", JOptionPane.ERROR_MESSAGE);
                    } else {
                        leaderBoardWindow();
                    }
                    break;
                case "Print Your Score to a File":
                    if (playerObject == null) {
                        JOptionPane.showMessageDialog(null, "Please Enter Your Name Before Continuing.", "Warning", JOptionPane.ERROR_MESSAGE);
                    } else {
                        printScoreToAFileWindow();
                    }
                    break;
                case "Exit":
                    System.out.println("Shutting Down.....");
                    System.exit(0);
                    break;
                default:
                    break;
            }
        }
    }

    public class OkStartButtonHandler implements ActionListener {//handler for Start OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

                System.out.println("OkStartButtonHandler " + command);

                if (command.equals("OK")) {
                    String firstName = firstNameTextField.getText();
                    String lastName = lastNameTextField.getText();

                    String fullName = firstName + " " + lastName;

                    int iD;
                    iD = (int) ((Math.random() * 1000) + 1);

                    int initialScore = 0;

                    Player_AN newPlayer = new Player_AN(iD, fullName, initialScore);

                    playerObject = newPlayer;
                    playerList.add(newPlayer);
                    numberOfQuestionsAnswered = 0;
                    gameInProgress = true;
                }

            informationFrame.dispose();

           questionWindow();

        }
    }

    public class CancelStartButtonHandler implements ActionListener {//handler for Start Cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("CancelStartButtonHandler " + command);

            if (command.equals("Cancel")) {
                informationFrame.dispose();//" "
            }
        }
    }

    public class NumberOneButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberOneButtonHandler " + command);

            if (command.equals("1")) {
                try {
                    numberOneWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberOneButtonHandler implements ActionListener {//handler for question 1 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("OKNumberOneButtonHandler" + command);

            if (command.equals("OK")) {
                if (numberOneChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberOneChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberOneChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberOneChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberOneFrame.dispose();
                numberOneButton.setBackground(Color.LIGHT_GRAY);
                numberOneButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberOneButtonHandler implements ActionListener {//handler for question 1 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("CancelNumberOneButtonHandler" + command);

            if (command.equals("Cancel")) {
                numberOneFrame.dispose();
            }
        }
    }


    public class NumberTwoButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("2")) {
                try {
                    numberTwoWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberTwoButtonHandler implements ActionListener {//handler for question 1 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("OkNumberTwoButtonHandler" + command);

            if (command.equals("OK")) {
                if (numberTwoChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberTwoChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                } else if (numberTwoChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberTwoChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberTwoFrame.dispose();
                numberTwoButton.setBackground(Color.LIGHT_GRAY);
                numberTwoButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberTwoButtonHandler implements ActionListener {//handler for question 1 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("CancelNumberTwoButtonHandler" + command);

            if (command.equals("Cancel")) {
                numberTwoFrame.dispose();
            }
        }
    }

    public class NumberThreeButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberThreeButtonHandler " + command);

            if (command.equals("3")) {
                try {
                    numberThreeWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberThreeButtonHandler implements ActionListener {//handler for question 3 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("OkNumberThreeButtonHandler " + command);

            if (command.equals("OK")) {
                if (numberThreeChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberThreeChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberThreeChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                } else if (numberThreeChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberThreeFrame.dispose();
                numberThreeButton.setBackground(Color.LIGHT_GRAY);
                numberThreeButton.setEnabled(false);
            }

        }
    }

    public class CancelNumberThreeButtonHandler implements ActionListener {//handler for question 3 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("CancelNumberThreeButtonHandler " + command);

            if (command.equals("Cancel")) {
                numberThreeFrame.dispose();
            }
        }
    }

    public class NumberFourButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberFourButtonHandler " + command);

            if (command.equals("4")) {
                try {
                    numberFourWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberFourButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                if (numberFourChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                } else if (numberFourChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberFourChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberFourChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberFourFrame.dispose();
                numberFourButton.setBackground(Color.LIGHT_GRAY);
                numberFourButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberFourButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberFourFrame.dispose();
            }
        }
    }

    public class NumberFiveButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberFiveButtonHandler " + command);

            if (command.equals("5")) {
                try {
                    numberFiveWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberFiveButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                if (numberFiveChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                } else if (numberFiveChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberFiveChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberFiveChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberFiveFrame.dispose();
                numberFiveButton.setBackground(Color.LIGHT_GRAY);
                numberFiveButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberFiveButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberFiveFrame.dispose();
            }
        }
    }


    public class NumberSixButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberSixButtonHandler " + command);

            if (command.equals("6")) {
                try {
                    numberSixWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberSixButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                if (numberSixChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberSixChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberSixChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberSixChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberSixFrame.dispose();
                numberSixButton.setBackground(Color.LIGHT_GRAY);
                numberSixButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberSixButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberSixFrame.dispose();
            }
        }
    }


    public class NumberSevenButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberSevenButtonHandler " + command);

            if (command.equals("7")) {
                try {
                    numberSevenWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberSevenButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                if (numberSevenChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberSevenChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                } else if (numberSevenChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberSevenChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberSevenFrame.dispose();
                numberSevenButton.setBackground(Color.LIGHT_GRAY);
                numberSevenButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberSevenButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberSevenFrame.dispose();
            }
        }
    }


    public class NumberEightButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberEightButtonHandler " + command);

            if (command.equals("8")) {
                try {
                    numberEightWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberEightButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                if (numberEightChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberEightChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberEightChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                } else if (numberEightChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberEightFrame.dispose();
                numberEightButton.setBackground(Color.LIGHT_GRAY);
                numberEightButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberEightButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberEightFrame.dispose();
            }
        }
    }


    public class NumberNineButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberNineButtonHandler " + command);

            if (command.equals("9")) {
                try {
                    numberNineWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberNineButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                if (numberNineChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberNineChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberNineChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                } else if (numberNineChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberNineFrame.dispose();
                numberNineButton.setBackground(Color.LIGHT_GRAY);
                numberNineButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberNineButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberNineFrame.dispose();
            }
        }
    }


    public class NumberTenButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            System.out.println("NumberTenButtonHandler " + command);

            if (command.equals("10")) {
                try {
                    numberTenWindow();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public class OkNumberTenButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                if (numberTenChoiceARadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberTenChoiceBRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberTenChoiceCRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Your Answer is Incorrect.", "Incorrect Answer", JOptionPane.ERROR_MESSAGE);
                    playerObject.setGameScore(0);
                } else if (numberTenChoiceDRadioButton.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Ding. Ding. Ding. You are correct!", "Correct Answer", JOptionPane.PLAIN_MESSAGE);
                    playerObject.setGameScore(1);
                }

                numberOfQuestionsAnswered++;
                if (numberOfQuestionsAnswered == 10) {
                    gameInProgress = false;
                    JOptionPane.showMessageDialog(null, "Congratulations! You've completed your quiz.", "Quiz Completion",JOptionPane.PLAIN_MESSAGE);
                    startFrame.dispose();
                }
                numberTenFrame.dispose();
                numberTenButton.setBackground(Color.LIGHT_GRAY);
                numberTenButton.setEnabled(false);
            }
        }
    }

    public class CancelNumberTenButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberTenFrame.dispose();
            }
        }
    }


    public class OkHelpButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                helpFrame.dispose();
            }

        }
    }

    public class OkResultsButtonHandler implements ActionListener {//handler for Results OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                resultsPlayerIDLabel.setVisible(true);
                resultsPlayerFullNameLabel.setVisible(true);
                resultsNumberOfQuestionsCorrectLabel.setVisible(true);
                resultsNumberOfQuestionsInCorrectLabel.setVisible(true);
            }

            resultsFrame.dispose();

        }
    }

    public class OkLeaderBoardButtonHandler implements ActionListener {//handler for Leader Board OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                leaderBoardFrame.dispose();
            }
        }
    }

    public class OkPrintScoreToAFileButtonHandler implements ActionListener {//handler for print score OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            try {
                if (command.equals("OK")) {
                    playerObject.generateResultsIntoFile();
                }
            }catch (IOException ioException) {
                throw new RuntimeException(ioException);
            }

            printScoreToAFileFrame.dispose();

        }
    }

    public class CancelPrintScoreToAFileButtonHandler implements ActionListener {//handler for print score cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                printScoreToAFileFrame.dispose();//" "
            }
        }
    }


    public static void main (String [] args) {
        GuessingGameGUI_AN guessingGameObject = new GuessingGameGUI_AN();
        guessingGameObject.setUpGui();
    }
}
