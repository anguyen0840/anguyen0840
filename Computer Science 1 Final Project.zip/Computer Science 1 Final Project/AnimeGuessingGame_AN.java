import java.util.*;//class that has the backbone of the game

public class AnimeGuessingGame_AN {

    Player_AN playerObj;
    Scanner userInput = new Scanner(System.in);

    public AnimeGuessingGame_AN(Player_AN playerObj) {
        this.playerObj = playerObj;
    }

    public char askQuestion1() {
        char answer;
        
        System.out.println("What Year Was the First Anime Recorded?");
        System.out.println("a. 1891");
        System.out.println("b. 1900");
        System.out.println("c. 1913");
        System.out.println("d. 1917");
        
        answer = userInput.next().charAt(0);

        return answer;
    }

    public char askQuestion2() {
        char answer;
        
        System.out.println("How Many Types of Pokemon Are There?");
        System.out.println("a. 15");
        System.out.println("b. 18");
        System.out.println("c. 20");
        System.out.println("d. 24");
        
        answer = userInput.next().charAt(0);

        return answer;
    }

    public char askQuestion3() {
        char answer;
        
        System.out.println("Who Has the Nickname of 'One Punch Man'?");
        System.out.println("a. Son Goku");
        System.out.println("b. Monkey D. Luffy");
        System.out.println("c. Saitama");
        System.out.println("d. Uzumaki Naruto");
        
        answer = userInput.next().charAt(0);
        
        return answer;
    }

    public char askQuestion4() {
        char answer;
        
        System.out.println("How Many Dragon Balls Are There?");
        System.out.println("a. 7");
        System.out.println("b. 8");
        System.out.println("c. 6");
        System.out.println("d. 9");
        
        answer = userInput.next().charAt(0);
        
        return answer;
    }

    public void isCorrectForQuestion1() {
        boolean continueGame = true;
        int numberOfGuesses = 0;

        char correctAnswer = 'D';
        char correctAnswer1 = 'd';

        try{
            while (continueGame && numberOfGuesses < 2) {
                char guess = askQuestion1();

                if (guess == correctAnswer) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                } else if (guess == correctAnswer1) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                } else {
                    System.out.println("That Is Incorrect!");
                    playerObj.setGameScore(0);
                    numberOfGuesses++;
                    continueGame = true;
                }
            }
        } catch (InputMismatchException ex) {
            userInput.next();//would catch and discard the character or symbol
            System.out.println("Not A Letter Choice. Please Enter A Letter Between A-D.");//print statement to show if user input is not a number that is 1 - 7
        }
    }

    public void isCorrectForQuestion2() {
        boolean continueGame = true;
        int numberOfGuesses = 0;

        char correctAnswer = 'B';
        char correctAnswer1 = 'b';
        try {
            while (continueGame && numberOfGuesses < 2) {
                char guess = askQuestion2();

                if (guess == correctAnswer) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                } else if (guess == correctAnswer1) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                }else {
                    System.out.println("That Is Incorrect!");
                    playerObj.setGameScore(0);
                    numberOfGuesses++;
                    continueGame = true;
                }
            }
        } catch (InputMismatchException ex) {
            userInput.next();//would catch and discard the character or symbol
            System.out.println("Not A Letter Choice. Please Enter A Letter Between A-D.");//print statement to show if user input is not a number that is 1 - 7
        }
    }

    public void isCorrectForQuestion3() {
        boolean continueGame = true;
        int numberOfGuesses = 0;

        char correctAnswer = 'C';
        char correctAnswer1 = 'c';
        try {
            while (continueGame && numberOfGuesses < 2) {
                char guess = askQuestion3();

                if (guess == correctAnswer) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                } else if (guess == correctAnswer1) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                }else {
                    System.out.println("That Is Incorrect!");
                    playerObj.setGameScore(0);
                    numberOfGuesses++;
                    continueGame = true;
                }
            }
        } catch (InputMismatchException ex) {
            userInput.next();//would catch and discard the character or symbol
            System.out.println("Not A Letter Choice. Please Enter A Letter Between A-D.");//print statement to show if user input is not a number that is 1 - 7
        }
    }

    public void isCorrectForQuestion4() {
        boolean continueGame = true;
        int numberOfGuesses = 0;

        char correctAnswer = 'A';
        char correctAnswer1 = 'a';
        try {
            while (continueGame && numberOfGuesses < 2) {
                char guess = askQuestion4();

                if (guess == correctAnswer) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                } else if (guess == correctAnswer1) {
                    System.out.println("Ding. Ding. Ding. You Are Correct!");
                    playerObj.setGameScore(1);
                    continueGame = false;
                }else {
                    System.out.println("That Is Incorrect!");
                    playerObj.setGameScore(0);
                    numberOfGuesses++;
                    continueGame = true;
                }
            }
        } catch (InputMismatchException ex) {
            userInput.next();//would catch and discard the character or symbol
            System.out.println("Not A Letter Choice. Please Enter A Letter Between A-D.");//print statement to show if user input is not a number that is 1 - 7
        }
    }


}
