import java.io.*;//rough draft for the GUI with everything done for checklist parameters
import java.util.*;//backbone to the game and GUI implements

public class SetUp_AN {
    AnimeGuessingGame_AN animeGuessingGameObj;
    Player_AN playerObject;
    Scanner userInput = new Scanner(System.in);

    List<Player_AN> playerInfo = new ArrayList<>();
    public SetUp_AN() {
        //Empty Constructor
    }

    public void startGame() {
        String firstName;
        System.out.println("What is your first name?");
        firstName = userInput.next();

        String lastName;
        System.out.println("What is your last name?");
        lastName = userInput.next();

        int iD;
        iD = (int)((Math.random()*1000)+1);

        int initialScore = 0;

        String fullName = firstName + " " + lastName;

        playerObject = new Player_AN(iD, fullName, initialScore);

        playerObject.setInfo(firstName, lastName, iD);
        playerObject.setGameScore(0);
        playerObject.printInfo();

        playerInfo.add(playerObject);

        System.out.println("Good Luck with on this Anime Guessing Game.");

        animeGuessingGameObj = new AnimeGuessingGame_AN(playerObject);
        animeGuessingGameObj.isCorrectForQuestion1();
        playerObject.printInfo();
        animeGuessingGameObj.isCorrectForQuestion2();
        playerObject.printInfo();
        animeGuessingGameObj.isCorrectForQuestion3();
        playerObject.printInfo();
        animeGuessingGameObj.isCorrectForQuestion4();
        playerObject.printInfo();
    }

    public void seeResults() {
       playerObject.generateResults();
    }

    public void viewLeaderBoard() {

    }

    public void  printScoreIntoAFile() throws IOException {
        playerObject.generateResultsIntoFile();
    }

    public void getHelp() {//method that corresponds to the Menu_AN interface method and option 7 for start() method to display instructions
        System.out.println("Welcome to Fake Bank North.");//used separate print statements to show the different lines for the instructions
        System.out.println("You will be directed to our bank's Main Menu.");
        System.out.println("You will have a choice to choose from.");
        System.out.println("It ranges from open an account, to making a deposit, withdrawing money , printing a bank statement, and to saving transactions into a text file.");
        System.out.println("They will be numbered from 1 - 7 on the menu.");
        System.out.println("It is recommended to make a checking and/or savings account first with us before proceeding with other transactions.");
        System.out.println("Or you would be in the unable to use our services more.");
        System.out.println("If you have any questions, call 1-(800) TO-NORTH, or 1-(800) 86-66784, to reach our Customer Service Number.");
        System.out.println("Hope you enjoy our services and open an account with us soon.");
    }

    public void exitMenu() {//method that corresponds to the Menu_AN interface method and option 6 for start() method to exit menu
        System.out.println("Thank You for Your Trust On Our Services Today. Hope You Have A Good Rest of Your Day.");//print statement seen before exiting the menu
        System.exit(0);//statement that gets out of the menu
    }

    public void printMenu() {//method that shows the menu for the bank account on the terminal
        System.out.println("Welcome to Fake Bank North.");//print statements on different lines to show greeting, prompt to get into game with choices of 1, 2, or 3, and each print shows choices of the numbers
        System.out.println("Enter 1 - 7 to make your choice.");
        System.out.println("1. Open An Account.");
        System.out.println("2. Add Money.");
        System.out.println("3. Withdraw Money.");
        System.out.println("4. Print Your Activity Statement.");
        System.out.println("5. Print Your Activity Statement Into A File.");
        System.out.println("6. Exit the Menu");
        System.out.println("7. Get Help.");
        System.out.println();
    }

    public void startMenu() throws IOException {//method that corresponds to the Menu_AN interface method that contains switch statement for printMenu()
        boolean playGame = true;//set variable as flag to indicate when to exit the loop

        while(playGame) {//while loop that cycle through switch statement until exit loop
            try {//try statement that allows switch statement to happen
                int menuOption = userInput.nextInt();//capture the user's input for the select menu from 1 to 7

                switch(menuOption) {
                    case 1:
                        startGame();//calls method that gets user to open a bank account
                        System.out.println("-------------------------------------------------");//divides method and print menu
                        printMenu();//shows the menu after completing the
                        break;//stops the print statement to get back to loop

                    case 2:
                        seeResults();//calls method to deposits money into bank account
                        System.out.println("-------------------------------------------------");//" "
                        printMenu();//" "
                        break;//" "

                    case 3:
                        viewLeaderBoard();//calls method that withdraws money out of bank account
                        System.out.println("-------------------------------------------------");//" "
                        printMenu();//" "
                        break;//" "


                    case 4:
                        printScoreIntoAFile();//calls method that prints transactions onto a text file
                        System.out.println("-------------------------------------------------");//" "
                        printMenu();//" "
                        break;//" "

                    case 5:
                        exitMenu();//calls method to exit the menu
                        playGame = false;
                        break;//" "

                    case 6:
                        getHelp();//calls method that shows instructions
                        System.out.println("-------------------------------------------------");//" "
                        printMenu();//" "
                        break;//" "

                    default:
                        System.out.println("Not a Choice. Please Try Again.");
                        break;//" "
                }
            }
            catch(InputMismatchException ex) {//catch statement that catches user input for letters and symbols
                userInput.next();//would catch and discard the character or symbol
                System.out.println("Not a Numerical Choice. Please Enter A Number Between 1-6.");//print statement to show if user input is not a number that is 1 - 7
            }
        }
    }

    public static void main(String[] args) {
        try {
            SetUp_AN setUpObject = new SetUp_AN();
            setUpObject.printMenu();
            setUpObject.startMenu();
        } catch (IOException ex) {
            System.out.println("Scanner Error");//Error message to occur if the methods fail the try statement
            ex.printStackTrace();//handles exception by pinpointing the exact line where method raised the exception
        }
    }
}
