public class Person_AN {
    private String firstName, lastName;//set class variables with first name, last name, and I.D. #
    int id;

    public Person_AN (){
        //Empty Constructor
    }

    public Person_AN(String firstName, String lastName, int id) {//method that creates a constructor by using the class as a data type return and set member variable to used parameters
        this.firstName = firstName;//allows the constructor to be used later when creating an object at a different class program
        this.lastName = lastName;
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setInfo(String fName, String lName, int iD) {//method that set the class member variables to the parameters used
        firstName = fName;//variable for first name
        lastName = lName;// " "
        id = iD;// " "
    }

    public String getInfo() {//method that returns a string back from variable set in the setInfo() method
        String personInfo;//declare variable
        personInfo = "Full Name: " + firstName + " " + lastName +  " ID: " + id;//set variable with first and last names along with I.D. #
        return personInfo;//return variable back
    }

    public void printInfo() {//method that prints the info from the string obtained at the getInfo() method
        System.out.println(getInfo());
    }
}

