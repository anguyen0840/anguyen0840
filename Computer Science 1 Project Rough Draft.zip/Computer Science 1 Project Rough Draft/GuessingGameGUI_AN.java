import javax.swing.*;//import for javax.swing, java.awt, java.awt.event, java.io
import java.awt.*;//have done the parameters of project on SetUp_AN but didn't put it in this program yet
import java.awt.event.*;
import java.io.*;

public class GuessingGameGUI_AN extends WindowAdapter {//list all class member variables
    Player_AN playerObject;
    Person_AN personObject;

    JFrame guessingGameFrame = new JFrame("Anime Guessing Game");
    JPanel guessingGamePanel = new JPanel(new FlowLayout());
    JLabel guessingGameLabel = new JLabel("Welcome to the Anime Guessing Game.");

    JButton oKStartButton = new JButton("OK");
    JButton cancelStartButton = new JButton("Cancel");

    JButton okNumberOneButton = new JButton("OK");
    JButton cancelNumberOneButton = new JButton("Cancel");

    JButton okNumberTwoButton = new JButton("OK");
    JButton cancelNumberTwoButton = new JButton("Cancel");

    JButton OkNumberThreeButton = new JButton("OK");
    JButton cancelNumberThreeButton = new JButton("Cancel");

    JButton OkNumberFourButton = new JButton("OK");
    JButton cancelNumberFourButton = new JButton("Cancel");

    JButton oKInformationButton = new JButton("OK");
    JButton cancelInformationButton = new JButton("Cancel");

    JButton oKResultsButton = new JButton("OK");

    JButton oKLeaderBoardButton = new JButton("OK");

    JButton oKHelpButton = new JButton("OK");

    JButton oKPrintScoreToAFileButton = new JButton("OK");
    JButton cancelPrintScoreToAFileButton = new JButton("Cancel");

    JButton startButton = new JButton("Start");
    JPanel startButtonPanel = new JPanel(new FlowLayout());
    JPanel startTextBoxPanel = new JPanel(new FlowLayout());
    JFrame startFrame = new JFrame("Start the Anime Guessing Game");

    JButton numberOneButton = new JButton("1");
    JFrame numberOneFrame = new JFrame("Anime Guessing Game Question 1");
    JPanel numberOneButtonPanel = new JPanel(new FlowLayout());
    JPanel numberOneTextBoxPanel = new JPanel(new FlowLayout());
    JLabel numberOneLabel = new JLabel("What Year Was the First Anime Recorded?");
    JLabel numberOneChoiceALabel = new JLabel("A. 1891");
    JLabel numberOneChoiceBLabel = new JLabel("B. 1900");
    JLabel numberOneChoiceCLabel = new JLabel("C. 1913");
    JLabel numberOneChoiceDLabel = new JLabel("D. 1917");
    JTextField numberOneResponseTextField = new JTextField(20);

    JButton numberTwoButton = new JButton("2");
    JFrame numberTwoFrame = new JFrame("Anime Guessing Game Question 2");
    JPanel numberTwoButtonPanel = new JPanel(new FlowLayout());
    JPanel numberTwoTextBoxPanel = new JPanel(new FlowLayout());
    JLabel numberTwoLabel = new JLabel("How Many Types of Pokemon Are There?");
    JLabel numberTwoChoiceALabel = new JLabel("A. 15");
    JLabel numberTwoChoiceBLabel = new JLabel("B. 18");
    JLabel numberTwoChoiceCLabel = new JLabel("C. 20");
    JLabel numberTwoChoiceDLabel = new JLabel("D. 24");
    JTextField numberTwoResponseTextField = new JTextField(20);

    JButton numberThreeButton = new JButton("3");
    JFrame numberThreeFrame = new JFrame("Anime Guessing Game Question 3");
    JPanel numberThreeButtonPanel = new JPanel(new FlowLayout());
    JPanel numberThreeTextBoxPanel = new JPanel(new FlowLayout());
    JLabel numberThreeLabel = new JLabel("Who Has the Nickname of 'One Punch Man'?");
    JLabel numberThreeChoiceALabel = new JLabel("A. Son Goku");
    JLabel numberThreeChoiceBLabel = new JLabel("B. Monkey D. Luffy");
    JLabel numberThreeChoiceCLabel = new JLabel("C. Saitama");
    JLabel numberThreeChoiceDLabel = new JLabel("D. Uzumaki Naruto");
    JTextField numberThreeResponseTextField = new JTextField(20);

    JButton numberFourButton = new JButton("4");
    JFrame numberFourFrame = new JFrame("Anime Guessing Game Question 4");
    JPanel numberFourButtonPanel = new JPanel(new FlowLayout());
    JPanel numberFourTextBoxPanel = new JPanel(new FlowLayout());
    JLabel numberFourLabel = new JLabel("How Many Dragon Balls Are There?");
    JLabel numberFourChoiceALabel = new JLabel("A. 7");
    JLabel numberFourChoiceBLabel = new JLabel("B. 8");
    JLabel numberFourChoiceCLabel = new JLabel("C. 6");
    JLabel numberFourChoiceDLabel = new JLabel("D. 9");
    JTextField numberFourResponseTextField = new JTextField(20);

    JFrame informationFrame = new JFrame("Player Information");
    JPanel informationButtonPanel = new JPanel(new FlowLayout());
    JPanel informationTextBoxPanel = new JPanel(new FlowLayout());
    JLabel firstNameLabel = new JLabel("First Name:");
    JTextField firstNameTextField = new JTextField(20);
    JLabel lastNameLabel = new JLabel("Last Name:");
    JTextField lastNameTextField = new JTextField(20);

    JButton helpButton = new JButton("Help");
    JFrame helpFrame = new JFrame("Help Instructions");
    JPanel helpButtonPanel = new JPanel(new FlowLayout());
    JPanel helpTextBoxPanel = new JPanel(new FlowLayout());
    JLabel helpLabel = new JLabel("Enter Deposit Amount:");

    JButton resultsButton = new JButton("Results");
    JFrame resultsFrame = new JFrame("Anime Guessing Game Results");
    JPanel resultsButtonPanel = new JPanel(new FlowLayout());
    JPanel resultsTextBoxPanel = new JPanel(new FlowLayout());
    JLabel resultsLabel = new JLabel("Here are Your Results: ");
    JLabel resultsPlayerIDLabel;
    JLabel resultsPlayerFullNameLabel;
    JLabel resultsNumberOfQuestionsCorrectLabel;
    JLabel resultsNumberOfQuestionsInCorrectLabel;

    JButton leaderBoardButton = new JButton("Leader Board");
    JFrame leaderBoardFrame = new JFrame("Anime Guessing Game Leader Board");
    JPanel leaderBoardButtonPanel = new JPanel(new FlowLayout());
    JPanel leaderBoardTextBoxPanel = new JPanel(new FlowLayout());
    JLabel leaderBoardLabel = new JLabel("2023 Leader Board");

    JButton printButton = new JButton("Print Your Score to a File");
    JFrame printScoreToAFileFrame = new JFrame("Print Your Score To A File");
    JPanel printScoreToAFileButtonPanel = new JPanel(new FlowLayout());
    JPanel printScoreToAFileTextBoxPanel = new JPanel(new FlowLayout());
    JLabel printScoreToAFileLabel = new JLabel("Printing Your Score......... ");
    JButton exitButton = new JButton("Exit");

    public void setUpGui() {//set up frame for the guessing game GUI
        guessingGameFrame.add(guessingGameLabel, BorderLayout.NORTH);
        guessingGameFrame.add(guessingGamePanel, BorderLayout.CENTER);
        guessingGameFrame.addWindowListener(this);
        guessingGameFrame.add(exitButton, BorderLayout.SOUTH);

        guessingGamePanel.setFont(new Font("Helvetica", Font.BOLD, 20));

        guessingGamePanel.add(startButton);
        guessingGamePanel.add(resultsButton);
        guessingGamePanel.add(leaderBoardButton);
        guessingGamePanel.add(helpButton);
        guessingGamePanel.add(printButton);

        guessingGamePanel.setBackground(Color.CYAN);

        startButton.setFont(new Font("Helvetica",Font.BOLD,50));
        startButton.setBackground(Color.DARK_GRAY);
        startButton.setForeground(Color.WHITE);

        resultsButton.setFont(new Font("Helvetica",Font.BOLD,50));
        resultsButton.setBackground(Color.DARK_GRAY);
        resultsButton.setForeground(Color.WHITE);

        leaderBoardButton.setFont(new Font("Helvetica",Font.BOLD,50));
        leaderBoardButton.setBackground(Color.DARK_GRAY);
        leaderBoardButton.setForeground(Color.WHITE);

        helpButton.setFont(new Font("Helvetica",Font.BOLD,50));
        helpButton.setBackground(Color.DARK_GRAY);
        helpButton.setForeground(Color.WHITE);

        printButton.setFont(new Font("Helvetica",Font.BOLD,50));
        printButton.setBackground(Color.DARK_GRAY);
        printButton.setForeground(Color.WHITE);

        exitButton.setFont(new Font("Helvetica",Font.BOLD,50));
        exitButton.setBackground(Color.DARK_GRAY);
        exitButton.setForeground(Color.WHITE);

        startButton.addActionListener(new MenuButtonHandler());
        resultsButton.addActionListener(new MenuButtonHandler());
        leaderBoardButton.addActionListener(new MenuButtonHandler());
        helpButton.addActionListener(new MenuButtonHandler());
        printButton.addActionListener(new MenuButtonHandler());
        exitButton.addActionListener(new MenuButtonHandler());

        guessingGameFrame.add(guessingGamePanel);

        guessingGameFrame.pack();
        guessingGameFrame.setSize(1200,700);
        guessingGameFrame.setResizable(false);
        Container c = guessingGameFrame.getContentPane();
        c.setBackground(Color.LIGHT_GRAY);
        guessingGameFrame.setVisible(true);
    }

    public void windowClosing(WindowEvent we) {
        System.out.println("Shutting Down.....");
        System.exit(0);
    }

    private void startGameWindow() {//sets up the frame for information
        informationFrame = new JFrame("Player Information");
        informationFrame.setDefaultCloseOperation(startFrame.DISPOSE_ON_CLOSE);
        startGameUI(informationFrame);
        informationFrame.setSize(600, 300);
        informationFrame.setLocationRelativeTo(null);
        informationFrame.setResizable(false);
        informationFrame.setVisible(true);
    }

    private void startGameUI(final JFrame informationFrame){//Sets up the labels and text fields for collecting first name and last name with color and button handling
        informationButtonPanel = new JPanel(new FlowLayout());//add back to frame when dispose() get rids of everything
        informationTextBoxPanel = new JPanel(new FlowLayout());
        oKStartButton= new JButton("OK");
        cancelStartButton = new JButton("Cancel");
        firstNameLabel = new JLabel("First Name:");
        firstNameTextField = new JTextField(20);
        lastNameLabel = new JLabel("Last Name:");
        lastNameTextField = new JTextField(20);

        informationTextBoxPanel.setLayout(new GridLayout(2, 2));

        informationButtonPanel.add(oKInformationButton);//OK and Cancel buttons gets added to panel
        informationButtonPanel.add(cancelInformationButton);

        oKInformationButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKInformationButton.setForeground(Color.WHITE);
        cancelInformationButton.setBackground(Color.DARK_GRAY);//sets color for Cancel button
        cancelInformationButton.setForeground(Color.WHITE);

        oKInformationButton.addActionListener(new OkStartButtonHandler());//sets handlers for OK and Cancel button
        cancelInformationButton.addActionListener(new CancelStartButtonHandler());

        informationButtonPanel.setBackground(Color.CYAN);//sets color for panel for open bank account for button panel

        informationFrame.add(informationButtonPanel);//add button panel to information frame

        informationTextBoxPanel.add(firstNameLabel);//sets color for first name label and text field
        numberOneButton.setForeground(Color.WHITE);
        numberOneButton.setBackground(Color.WHITE);

        informationTextBoxPanel.add(firstNameTextField);
        numberTwoButton.setBackground(Color.WHITE);
        numberTwoButton.setBackground(Color.WHITE);

        informationTextBoxPanel.add(lastNameLabel);//sets color for last name label and text field
        numberOneButton.setForeground(Color.WHITE);
        numberOneButton.setBackground(Color.WHITE);

        informationTextBoxPanel.add(lastNameTextField);
        numberTwoButton.setBackground(Color.WHITE);
        numberTwoButton.setBackground(Color.WHITE);

        informationTextBoxPanel.setBackground(Color.DARK_GRAY);//sets color for panel for player information text field

        informationFrame.add(informationTextBoxPanel);//add player information text panel to information frame

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, informationTextBoxPanel, informationButtonPanel);//set up split panel for information frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        informationFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void questionWindow() {//sets up the frame for all questions
        startFrame = new JFrame("Start the Anime Guessing Game");
        startFrame.setDefaultCloseOperation(startFrame.DISPOSE_ON_CLOSE);
        questionUI(startFrame);
        startFrame.setSize(600, 300);
        startFrame.setLocationRelativeTo(null);
        startFrame.setResizable(false);
        startFrame.setVisible(true);
    }

    private void questionUI(final JFrame startFrame){//Sets up the labels and text fields for questions with color and button handling
        startButtonPanel = new JPanel(new FlowLayout());//add back to frame when dispose() get rids of everything
        oKStartButton= new JButton("OK");
        cancelStartButton = new JButton("Cancel");
        startTextBoxPanel = new JPanel(new FlowLayout());
        numberOneButton = new JButton("1");
        numberTwoButton = new JButton("2");
        numberThreeButton = new JButton("3");
        numberFourButton = new JButton("4");

        startButtonPanel.add(oKStartButton);//OK and Cancel buttons gets added to panel
        startButtonPanel.add(cancelStartButton);

        oKStartButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKStartButton.setForeground(Color.WHITE);
        cancelStartButton.setBackground(Color.DARK_GRAY);//sets color for Cancel button
        cancelStartButton.setForeground(Color.WHITE);

        oKStartButton.addActionListener(new OkStartButtonHandler());//sets handlers for OK and Cancel button
        cancelStartButton.addActionListener(new CancelStartButtonHandler());

        startButtonPanel.setBackground(Color.CYAN);//sets color for panel for open bank account for button panel

        startFrame.add(startButtonPanel);//add button panel to questions rame

        startTextBoxPanel.add(numberOneButton);//sets color for first name label and text field
        numberOneButton.setForeground(Color.DARK_GRAY);
        numberOneButton.setBackground(Color.WHITE);
        startTextBoxPanel.add(numberTwoButton);
        numberTwoButton.setBackground(Color.DARK_GRAY);
        numberTwoButton.setBackground(Color.WHITE);

        numberOneButton.addActionListener(new NumberOneButtonHandler());
        numberTwoButton.addActionListener(new NumberTwoButtonHandler());
        numberThreeButton.addActionListener(new NumberThreeButtonHandler());
        numberFourButton.addActionListener(new NumberFourButtonHandler());

        startTextBoxPanel.add(numberThreeButton);//sets color for last name label and text field
        numberThreeButton.setForeground(Color.DARK_GRAY);
        numberThreeButton.setBackground(Color.WHITE);
        startTextBoxPanel.add(numberFourButton);
        numberFourButton.setBackground(Color.DARK_GRAY);
        numberFourButton.setBackground(Color.WHITE);

        startTextBoxPanel.setBackground(Color.DARK_GRAY);//sets color for panel for

        startFrame.add(startTextBoxPanel);//add open bank account text panel to frame
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, startTextBoxPanel, startButtonPanel);//set up split panel for open bank account frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        startFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void numberOneWindow() {//sets up the frame for question 1
        numberOneFrame = new JFrame("Anime Guessing Game Question 1");
        numberOneFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberOneUI(numberOneFrame);
        numberOneFrame.setSize(600, 300);
        numberOneFrame.setLocationRelativeTo(null);
        numberOneFrame.setResizable(false);
        numberOneFrame.setVisible(true);
    }

    private void numberOneUI(final JFrame numberOneFrame){//Sets up the labels and text fields for question 1 with color and button handling
        numberOneButtonPanel = new JPanel(new FlowLayout());
        okNumberOneButton = new JButton("OK");
        cancelNumberOneButton = new JButton("Cancel");

        numberOneButtonPanel = new JPanel(new FlowLayout());
        helpLabel = new JLabel("What Year Was the First Anime Recorded?");
        numberOneChoiceALabel = new JLabel("A. 1891");
        numberOneChoiceBLabel = new JLabel("B. 1900");
        numberOneChoiceCLabel = new JLabel("C. 1913");
        numberOneChoiceDLabel = new JLabel("D. 1917");
        numberOneResponseTextField = new JTextField(20);

        numberOneButtonPanel.add(oKHelpButton);
        numberOneButtonPanel.add(cancelNumberOneButton);

        okNumberOneButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        okNumberOneButton.setForeground(Color.WHITE);
        cancelNumberOneButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        cancelNumberOneButton.setForeground(Color.WHITE);

        okNumberOneButton.addActionListener(new OkNumberOneButtonHandler());//handling for OK and Cancel button
        cancelNumberOneButton.addActionListener(new CancelNumberOneButtonHandler());

        numberOneFrame.add(numberOneButtonPanel);//add button panel to frame
        numberOneButtonPanel.setBackground(Color.CYAN);// sets color for button panel

        numberOneTextBoxPanel.add(numberOneLabel);//add labels to text panel
        numberOneTextBoxPanel.add(numberOneChoiceALabel);
        numberOneTextBoxPanel.add(numberOneChoiceBLabel);
        numberOneTextBoxPanel.add(numberOneChoiceCLabel);
        numberOneTextBoxPanel.add(numberOneChoiceDLabel);
        numberOneTextBoxPanel.add(numberOneResponseTextField);

        numberOneLabel.setForeground(Color.WHITE);
        numberOneChoiceALabel.setForeground(Color.WHITE);
        numberOneChoiceBLabel.setForeground(Color.WHITE);
        numberOneChoiceCLabel.setForeground(Color.WHITE);
        numberOneChoiceDLabel.setForeground(Color.WHITE);
        numberOneResponseTextField.setForeground(Color.WHITE);

        numberOneTextBoxPanel.setBackground(Color.DARK_GRAY);

        numberOneFrame.add(numberOneTextBoxPanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, numberOneTextBoxPanel, numberOneButtonPanel);//set up split panel for question 1 frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        numberOneFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void numberTwoWindow() {//sets up the frame for question 2 to Bank Account
        numberTwoFrame = new JFrame("Anime Guessing Game Question 2");
        numberTwoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        numberTwoUI(numberTwoFrame);
        numberTwoFrame.setSize(600, 300);
        numberTwoFrame.setLocationRelativeTo(null);
        numberTwoFrame.setResizable(false);
        numberTwoFrame.setVisible(true);
    }

    private void numberTwoUI(final JFrame numberTwoFrame){//Sets up the labels and text fields for question 2 with color and button handling
        numberTwoButtonPanel = new JPanel(new FlowLayout());
        okNumberTwoButton= new JButton("OK");
        cancelNumberTwoButton = new JButton("Cancel");

        numberTwoTextBoxPanel = new JPanel(new FlowLayout());
        numberTwoLabel = new JLabel("How Many Types of Pokemon Are There?");
        numberTwoChoiceALabel = new JLabel("A. 15");
        numberTwoChoiceBLabel = new JLabel("B. 18");
        numberTwoChoiceCLabel = new JLabel("C. 20");
        numberTwoChoiceDLabel = new JLabel("D. 24");
        numberTwoResponseTextField = new JTextField(20);

        numberTwoButtonPanel.add(okNumberTwoButton);

        okNumberTwoButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        okNumberTwoButton.setForeground(Color.WHITE);

        okNumberTwoButton.addActionListener(new OkHelpButtonHandler());//handling for OK and Cancel button
        cancelNumberTwoButton.addActionListener(new CancelNumberTwoButtonHandler());

        numberTwoFrame.add(numberTwoButtonPanel);//add button panel to frame
        numberOneButtonPanel.setBackground(Color.CYAN);// sets color for button panel

        numberTwoTextBoxPanel.add(numberTwoLabel);//add deposit JLabel to deposit text panel
        numberTwoTextBoxPanel.add(numberTwoChoiceALabel);
        numberTwoTextBoxPanel.add(numberTwoChoiceBLabel);
        numberTwoTextBoxPanel.add(numberTwoChoiceCLabel);
        numberTwoTextBoxPanel.add(numberTwoChoiceDLabel);
        numberTwoTextBoxPanel.add(numberTwoResponseTextField);

        numberTwoLabel.setForeground(Color.WHITE);
        numberTwoChoiceALabel.setForeground(Color.WHITE);
        numberTwoChoiceBLabel.setForeground(Color.WHITE);
        numberTwoChoiceCLabel.setForeground(Color.WHITE);
        numberTwoChoiceDLabel.setForeground(Color.WHITE);
        numberTwoResponseTextField.setForeground(Color.WHITE);

        numberTwoTextBoxPanel.setBackground(Color.DARK_GRAY);

        numberTwoFrame.add(numberTwoTextBoxPanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, numberTwoTextBoxPanel, numberTwoButtonPanel);
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        numberTwoFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    //will finish for questions 3 & 4
    //Might add more questions

    private void helpWindow() {//sets up the frame for help
        helpFrame = new JFrame("Help Instructions");
        helpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        helpUI(helpFrame);
        helpFrame.setSize(600, 300);
        helpFrame.setLocationRelativeTo(null);
        helpFrame.setResizable(false);
        helpFrame.setVisible(true);
    }

    private void helpUI(final JFrame helpFrame){//Sets up the labels and text fields for deposit with color and button handling
        helpButtonPanel = new JPanel(new FlowLayout());
        oKHelpButton = new JButton("OK");
        helpTextBoxPanel = new JPanel(new FlowLayout());
        helpLabel = new JLabel("Instructions");

        helpButtonPanel.add(oKHelpButton);

        oKHelpButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKHelpButton.setForeground(Color.WHITE);

        oKHelpButton.addActionListener(new OkHelpButtonHandler());//handling for OK and Cancel button

        helpFrame.add(helpButtonPanel);//add button panel to frame
        helpButtonPanel.setBackground(Color.CYAN);// sets color for button panel

        helpTextBoxPanel.add(helpLabel);//add deposit JLabel to deposit text panel
        helpLabel.setForeground(Color.WHITE);// sets color for deposit label and text field

        helpTextBoxPanel.setBackground(Color.DARK_GRAY);

        helpFrame.add(helpTextBoxPanel);//add panel to frame

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, helpTextBoxPanel, helpButtonPanel);//set up split panel for panel
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        helpFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void resultsWindow() {//had an issue with loading the window and pops up print score to file window as well
        resultsFrame = new JFrame("Anime Guessing Game Results");
        resultsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        resultsUI(resultsFrame);
        resultsFrame.setSize(600, 300);
        resultsFrame.setLocationRelativeTo(null);
        resultsFrame.setResizable(false);
        resultsFrame.setVisible(true);
    }

    private void resultsUI(final JFrame resultsFrame){//Sets up the labels and text fields for deposit with color and button handling
        resultsButtonPanel = new JPanel(new FlowLayout());
        resultsTextBoxPanel = new JPanel(new FlowLayout());
        resultsLabel = new JLabel("Here are Your Results: ");
        oKResultsButton = new JButton("OK");

        resultsButtonPanel.add(oKResultsButton);

        oKResultsButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKResultsButton.setForeground(Color.WHITE);

        oKResultsButton.addActionListener(new OkResultsButtonHandler());//handling for OK and Cancel button

        resultsFrame.add(resultsButtonPanel);//add button panel to frame
        resultsButtonPanel.setBackground(Color.CYAN);// sets color for button panel

        resultsTextBoxPanel.add(resultsLabel);//add deposit JLabel to deposit text panel
        resultsLabel.setForeground(Color.WHITE);// sets color for deposit label and text field

        resultsTextBoxPanel.setBackground(Color.DARK_GRAY);

        resultsPlayerIDLabel = new JLabel("ID: " + playerObject.getPlayerID());
        resultsPlayerFullNameLabel = new JLabel("Player's Name: " + playerObject.getFirstName() + " " + playerObject.getLastName());
        resultsNumberOfQuestionsCorrectLabel = new JLabel("Number of Correct Answers: " + playerObject.getGameScore());
        resultsNumberOfQuestionsInCorrectLabel = new JLabel("Number of Correct Answers: " + (4 - playerObject.getGameScore()));

        resultsTextBoxPanel.add(resultsPlayerIDLabel);
        resultsTextBoxPanel.add(resultsPlayerFullNameLabel);
        resultsTextBoxPanel.add(resultsNumberOfQuestionsCorrectLabel);
        resultsTextBoxPanel.add(resultsNumberOfQuestionsInCorrectLabel);

        resultsPlayerIDLabel.setForeground(Color.WHITE);
        resultsPlayerFullNameLabel.setForeground(Color.WHITE);
        resultsNumberOfQuestionsCorrectLabel.setForeground(Color.WHITE);
        resultsNumberOfQuestionsInCorrectLabel.setForeground(Color.WHITE);

        resultsFrame.add(resultsTextBoxPanel);//sets color for panel for open bank account text field

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, resultsTextBoxPanel, resultsButtonPanel);//set up split panel for open bank account frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        resultsFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void leaderBoardWindow() {//sets up the frame for leader board and had an issue with loading the window and pops up print score to file window as well
        leaderBoardFrame = new JFrame("Anime Guessing Game Leader Board");
        leaderBoardFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        leaderBoardUI(leaderBoardFrame);
        leaderBoardFrame.setSize(600, 300);
        leaderBoardFrame.setLocationRelativeTo(null);
        leaderBoardFrame.setResizable(false);
        leaderBoardFrame.setVisible(true);
    }

    private void leaderBoardUI(final JFrame leaderBoardFrame){//Sets up the labels and text fields for leader board with color and button handling
        leaderBoardButtonPanel = new JPanel(new FlowLayout());
        oKLeaderBoardButton = new JButton("OK");
        leaderBoardTextBoxPanel = new JPanel(new FlowLayout());
        leaderBoardLabel = new JLabel("2023 Leader Board");

        leaderBoardButtonPanel.add(oKLeaderBoardButton);

        oKLeaderBoardButton.setBackground(Color.DARK_GRAY);//sets color for OK button
        oKLeaderBoardButton.setForeground(Color.WHITE);

        oKLeaderBoardButton.addActionListener(new OkLeaderBoardButtonHandler());//handling for OK and Cancel button

        leaderBoardFrame.add(leaderBoardButtonPanel);//add button panel to frame
        leaderBoardButtonPanel.setBackground(Color.CYAN);// sets color for button panel

        leaderBoardTextBoxPanel.add(leaderBoardLabel);//add deposit JLabel to deposit text panel
        leaderBoardLabel.setForeground(Color.WHITE);// sets color for deposit label and text field

        leaderBoardTextBoxPanel.setBackground(Color.DARK_GRAY);

        leaderBoardFrame.add(leaderBoardTextBoxPanel);//sets color for panel for open bank account text field

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, helpTextBoxPanel, helpButtonPanel);//set up split panel for open bank account frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        leaderBoardFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    private void printScoreToAFileWindow() {// " "
        printScoreToAFileFrame = new JFrame("Print Your Score To A File");
        printScoreToAFileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        printScoreToAFileUI(printScoreToAFileFrame);
        printScoreToAFileFrame.setSize(600, 300);
        printScoreToAFileFrame.setLocationRelativeTo(null);
        printScoreToAFileFrame.setResizable(false);
        printScoreToAFileFrame.setVisible(true);
    }

    private void printScoreToAFileUI(final JFrame printScoreToAFileFrame) {//Sets up the labels for window to show printing to text with color and button handling
        printScoreToAFileButtonPanel = new JPanel(new FlowLayout());
        printScoreToAFileTextBoxPanel = new JPanel(new FlowLayout());
        oKPrintScoreToAFileButton = new JButton("OK");
        cancelPrintScoreToAFileButton = new JButton("Cancel");
        printScoreToAFileLabel = new JLabel("Printing Your Score......... ");

        printScoreToAFileButtonPanel.add(oKPrintScoreToAFileButton);//" "
        printScoreToAFileButtonPanel.add(cancelPrintScoreToAFileButton);

        oKPrintScoreToAFileButton.setBackground(Color.DARK_GRAY);//" "
        oKPrintScoreToAFileButton.setForeground(Color.WHITE);
        cancelPrintScoreToAFileButton.setBackground(Color.DARK_GRAY);//" "
        cancelPrintScoreToAFileButton.setForeground(Color.WHITE);

        oKPrintScoreToAFileButton.addActionListener(new OkPrintScoreToAFileButtonHandler());//" "
        cancelPrintScoreToAFileButton.addActionListener(new CancelPrintScoreToAFileButtonHandler());

        printScoreToAFileFrame.add(printScoreToAFileButtonPanel);//" "
        printScoreToAFileButtonPanel.setBackground(Color.CYAN);

        printScoreToAFileTextBoxPanel.add(printScoreToAFileLabel);//" "
        printScoreToAFileLabel.setForeground(Color.WHITE);

        printScoreToAFileTextBoxPanel.setBackground(Color.DARK_GRAY);


        printScoreToAFileFrame.add(printScoreToAFileTextBoxPanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, printScoreToAFileTextBoxPanel, printScoreToAFileButtonPanel);//set up split panel for print statement activities frame
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(100);
        printScoreToAFileFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    }

    public class MenuButtonHandler implements  ActionListener {//button handler for menu screen when opening GUI
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            switch(command) {
                case "Start":
                    startGameWindow();
                    break;
                case "Help":
                    helpWindow();
                    break;
                case "Results":
                    resultsWindow();
                case "Leader Board":
                    leaderBoardWindow();
                case "Print Your Score to a File":
                    printScoreToAFileWindow();
                    break;
                case "Exit":
                    System.out.println("Shutting Down.....");
                    System.exit(0);
                    break;
                default:
                    break;
            }
        }
    }

    public class OkStartButtonHandler implements ActionListener {//handler for Start OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

                if (command.equals("OK")) {
                    questionWindow();

                    String firstName = firstNameTextField.getText();
                    String lastName = lastNameTextField.getText();

                    String fullName = firstName + " " + lastName;

                    int iD;
                    iD = (int)((Math.random()*1000)+1);

                    int initialScore = 0;

                    personObject = new Person_AN(firstName, lastName, iD);
                    playerObject = new Player_AN(iD, fullName, initialScore);

                    informationFrame.dispose();

                    questionWindow();
                }
        }
    }

    public class CancelStartButtonHandler implements ActionListener {//handler for Start Cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                startFrame.dispose();//" "
            }
        }
    }

    public class OkHelpButtonHandler implements ActionListener {//handler for Help OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                helpFrame.dispose();
            }

        }
    }

    public class OkResultsButtonHandler implements ActionListener {//handler for Results OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                resultsFrame.dispose();
            }

        }
    }

    public class OkLeaderBoardButtonHandler implements ActionListener {//handler for Leader Board OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("OK")) {
                leaderBoardFrame.dispose();
            }
        }
    }

    public class OkPrintScoreToAFileButtonHandler implements ActionListener {//handler for print score OK
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            try {
                if (command.equals("OK")) {
                    playerObject.generateResultsIntoFile();
                }
            }catch (IOException ioException) {
                throw new RuntimeException(ioException);
            }

            printScoreToAFileFrame.dispose();

        }
    }

    public class CancelPrintScoreToAFileButtonHandler implements ActionListener {//handler for print score cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                printScoreToAFileFrame.dispose();//" "
            }
        }
    }

    public class NumberOneButtonHandler implements ActionListener {//handler for button 1 for questions frame
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("1")) {
                numberOneWindow();
            }

            startFrame.dispose();
        }
    }

    public class OkNumberOneButtonHandler implements ActionListener {//handler for question 1 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

                if (command.equals("OK")) {

                }

            numberOneFrame.dispose();

        }
    }

    public class CancelNumberOneButtonHandler implements ActionListener {//handler for question 1 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberOneFrame.dispose();
            }
        }
    }

    public class NumberTwoButtonHandler implements ActionListener {//handler for button 2 for questions frame
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("2")) {
               numberTwoWindow();
            }
        }
    }

    public class OkNumberTwoButtonHandler implements ActionListener {//handler for question 2 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();


                if (command.equals("OK")) {

                }

            numberTwoFrame.dispose();

        }
    }

    public class CancelNumberTwoButtonHandler implements ActionListener {//handler for question 2 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberTwoFrame.dispose();
            }
        }
    }

    public class NumberThreeButtonHandler implements ActionListener {//handler for button 3 for questions frame
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("3")) {

            }
        }
    }

    public class OkNumberThreeButtonHandler implements ActionListener {//handler for question 3 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();


            if (command.equals("OK")) {

            }

            numberThreeFrame.dispose();

        }
    }

    public class CancelNumberThreeButtonHandler implements ActionListener {//handler for question 3 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberThreeFrame.dispose();
            }
        }
    }

    public class NumberFourButtonHandler implements ActionListener {//handler for button 4 for questions frame
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("4")) {
                printScoreToAFileFrame.dispose();//" "
            }
        }
    }

    public class OkNumberFourButtonHandler implements ActionListener {//handler for question 4 ok
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

                if (command.equals("OK")) {

                }
        }
    }

    public class CancelNumberFourButtonHandler implements ActionListener {//handler for question 4 cancel
        public void actionPerformed(ActionEvent ae) {
            String command = ae.getActionCommand();

            if (command.equals("Cancel")) {
                numberFourFrame.dispose();
            }
        }
    }

    public static void main (String [] args) {
        GuessingGameGUI_AN guessingGameObject = new GuessingGameGUI_AN();
        guessingGameObject.setUpGui();
    }
}
